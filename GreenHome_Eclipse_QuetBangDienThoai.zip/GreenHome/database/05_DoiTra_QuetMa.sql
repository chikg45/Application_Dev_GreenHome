﻿USE [QuanLyBanHang];
GO
SET ANSI_NULLS ON; SET ANSI_PADDING ON; SET ANSI_WARNINGS ON; SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON; SET QUOTED_IDENTIFIER ON; SET NUMERIC_ROUNDABORT OFF;
SET XACT_ABORT ON;
BEGIN TRY
BEGIN TRANSACTION;
-- Ràng buộc CHECK gốc của bản xuất SSMS có tên do SQL Server sinh.
DECLARE @old sysname;
SELECT @old=name FROM sys.check_constraints
WHERE parent_object_id=OBJECT_ID(N'dbo.PhieuDoiTra')
  AND REPLACE(REPLACE(REPLACE(REPLACE(definition, '(', ''), ')', ''), '[', ''), ']', '') =
      'trangThaiDuyet=''TU_CHOI'' OR trangThaiDuyet=''DA_DUYET'' OR trangThaiDuyet=''CHO_DUYET''';
IF @old IS NOT NULL
BEGIN
    DECLARE @drop nvarchar(400) = N'ALTER TABLE dbo.PhieuDoiTra DROP CONSTRAINT ' + QUOTENAME(@old);
    EXEC sp_executesql @drop;
END;
IF OBJECT_ID(N'dbo.CK_GH_Phieu_TrangThai', N'C') IS NULL
    ALTER TABLE dbo.PhieuDoiTra WITH CHECK ADD CONSTRAINT CK_GH_Phieu_TrangThai
        CHECK (trangThaiDuyet IN ('CHO_DUYET','DA_DUYET','TU_CHOI','HOAN_TAT'));

IF OBJECT_ID(N'dbo.LichSuDoiTra', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.LichSuDoiTra (
        id bigint IDENTITY PRIMARY KEY,
        maPhieu varchar(20) NOT NULL REFERENCES dbo.PhieuDoiTra(maPhieuDoiTra),
        suKien varchar(20) NOT NULL,
        maNV varchar(20) NOT NULL REFERENCES dbo.NhanVien(maNV),
        thoiDiem datetime2 NULL DEFAULT SYSDATETIME(),
        tienHoanDuKien decimal(18,2) NULL,
        tienHoanThucTe decimal(18,2) NULL,
        chenhLechDoi decimal(18,2) NULL,
        phuongThuc varchar(30) NULL
    );
    CREATE UNIQUE INDEX UX_GH_HoanTat ON dbo.LichSuDoiTra(maPhieu) WHERE suKien='HOAN_TAT';
    INSERT dbo.LichSuDoiTra(maPhieu,suKien,maNV,thoiDiem)
       SELECT maPhieuDoiTra,'TIEP_NHAN',maNV,ngayLap FROM dbo.PhieuDoiTra;
    INSERT dbo.LichSuDoiTra(maPhieu,suKien,maNV,thoiDiem)
       SELECT maPhieuDoiTra,trangThaiDuyet,maNVDuyet,NULL FROM dbo.PhieuDoiTra
       WHERE trangThaiDuyet IN ('DA_DUYET','TU_CHOI') AND maNVDuyet IS NOT NULL;
END;
IF COL_LENGTH('dbo.ChiTietPhieuDoiTra','giaTriGoc') IS NULL
    ALTER TABLE dbo.ChiTietPhieuDoiTra ADD giaTriGoc decimal(18,2) NULL;
IF COL_LENGTH('dbo.ChiTietPhieuDoiTra','maSPThayThe') IS NULL
    ALTER TABLE dbo.ChiTietPhieuDoiTra ADD maSPThayThe varchar(20) NULL REFERENCES dbo.SanPham(maSP);
IF COL_LENGTH('dbo.ChiTietPhieuDoiTra','giaThayThe') IS NULL
    ALTER TABLE dbo.ChiTietPhieuDoiTra ADD giaThayThe decimal(18,2) NULL;
IF OBJECT_ID(N'dbo.MaQuetSanPham', N'U') IS NULL
    CREATE TABLE dbo.MaQuetSanPham (
        maQuet nvarchar(128) PRIMARY KEY,
        maSP varchar(20) NOT NULL REFERENCES dbo.SanPham(maSP) ON DELETE CASCADE
    );
EXEC sys.sp_executesql N'IF OBJECT_ID(N''dbo.CK_GreenHome_KhachHang_Ten'', N''C'') IS NULL
    ALTER TABLE dbo.KhachHang WITH CHECK ADD CONSTRAINT CK_GreenHome_KhachHang_Ten
        CHECK (LEN(LTRIM(RTRIM(tenKH))) BETWEEN 2 AND 50);
ELSE
    ALTER TABLE dbo.KhachHang WITH CHECK CHECK CONSTRAINT CK_GreenHome_KhachHang_Ten;

IF OBJECT_ID(N''dbo.CK_GreenHome_KhachHang_SDT'', N''C'') IS NULL
    ALTER TABLE dbo.KhachHang WITH CHECK ADD CONSTRAINT CK_GreenHome_KhachHang_SDT
        CHECK (DATALENGTH(sdtKH)=10 AND sdtKH COLLATE Latin1_General_100_BIN2 LIKE ''0[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'');
ELSE
    ALTER TABLE dbo.KhachHang WITH CHECK CHECK CONSTRAINT CK_GreenHome_KhachHang_SDT;

IF OBJECT_ID(N''dbo.CK_GreenHome_NhanVien_Ngay'', N''C'') IS NULL
    ALTER TABLE dbo.NhanVien WITH CHECK ADD CONSTRAINT CK_GreenHome_NhanVien_Ngay
        CHECK (ngaySinh<=DATEADD(year,-18,CONVERT(date,GETDATE())) AND ngayVaoLam BETWEEN ngaySinh AND CONVERT(date,GETDATE()));
ELSE
    ALTER TABLE dbo.NhanVien WITH CHECK CHECK CONSTRAINT CK_GreenHome_NhanVien_Ngay;

IF OBJECT_ID(N''dbo.CK_GreenHome_TaiKhoan_DangNhap'', N''C'') IS NULL
    ALTER TABLE dbo.TaiKhoan WITH CHECK ADD CONSTRAINT CK_GreenHome_TaiKhoan_DangNhap
        CHECK (DATALENGTH(tenDangNhap) BETWEEN 4 AND 30 AND tenDangNhap COLLATE Latin1_General_100_BIN2 NOT LIKE ''%[^A-Za-z0-9_]%'' AND LEN(tenDangNhap)=DATALENGTH(tenDangNhap));
ELSE
    ALTER TABLE dbo.TaiKhoan WITH CHECK CHECK CONSTRAINT CK_GreenHome_TaiKhoan_DangNhap;

IF OBJECT_ID(N''dbo.CK_GreenHome_SanPham_Ma'', N''C'') IS NULL
    ALTER TABLE dbo.SanPham WITH CHECK ADD CONSTRAINT CK_GreenHome_SanPham_Ma
        CHECK (LEN(LTRIM(RTRIM(maSP)))>0);
ELSE
    ALTER TABLE dbo.SanPham WITH CHECK CHECK CONSTRAINT CK_GreenHome_SanPham_Ma;

IF OBJECT_ID(N''dbo.CK_GreenHome_SanPham_TonBan'', N''C'') IS NULL
    ALTER TABLE dbo.SanPham WITH CHECK ADD CONSTRAINT CK_GreenHome_SanPham_TonBan
        CHECK ((tinhTrang=''NGUNG_KINH_DOANH'' OR (tinhTrang=''HET_HANG'' AND soLuongTon=soLuongLoi) OR (tinhTrang=''DANG_KINH_DOANH'' AND soLuongTon>soLuongLoi)));
ELSE
    ALTER TABLE dbo.SanPham WITH CHECK CHECK CONSTRAINT CK_GreenHome_SanPham_TonBan;

IF OBJECT_ID(N''dbo.CK_GreenHome_KhuyenMai_Ten'', N''C'') IS NULL
    ALTER TABLE dbo.KhuyenMai WITH CHECK ADD CONSTRAINT CK_GreenHome_KhuyenMai_Ten
        CHECK (LEN(LTRIM(RTRIM(tenKM))) BETWEEN 2 AND 100);
ELSE
    ALTER TABLE dbo.KhuyenMai WITH CHECK CHECK CONSTRAINT CK_GreenHome_KhuyenMai_Ten;

IF OBJECT_ID(N''dbo.CK_GreenHome_KhuyenMai_MucGiam'', N''C'') IS NULL
    ALTER TABLE dbo.KhuyenMai WITH CHECK ADD CONSTRAINT CK_GreenHome_KhuyenMai_MucGiam
        CHECK ((loaiGiam=''PHAN_TRAM'' AND phanTramGiam>0 AND phanTramGiam<=100 AND soTienGiam=0) OR (loaiGiam=''SO_TIEN'' AND phanTramGiam=0 AND soTienGiam>0));
ELSE
    ALTER TABLE dbo.KhuyenMai WITH CHECK CHECK CONSTRAINT CK_GreenHome_KhuyenMai_MucGiam;

IF OBJECT_ID(N''dbo.CK_GreenHome_CaLamViec_Ten'', N''C'') IS NULL
    ALTER TABLE dbo.CaLamViec WITH CHECK ADD CONSTRAINT CK_GreenHome_CaLamViec_Ten
        CHECK (LEN(LTRIM(RTRIM(tenCa))) BETWEEN 2 AND 50);
ELSE
    ALTER TABLE dbo.CaLamViec WITH CHECK CHECK CONSTRAINT CK_GreenHome_CaLamViec_Ten;

IF OBJECT_ID(N''dbo.CK_GreenHome_PhanCongCa_Ma'', N''C'') IS NULL
    ALTER TABLE dbo.PhanCongCa WITH CHECK ADD CONSTRAINT CK_GreenHome_PhanCongCa_Ma
        CHECK (DATALENGTH(maPhanCong) BETWEEN 5 AND 10 AND LEFT(maPhanCong,2) COLLATE Latin1_General_100_BIN2=''PC'' AND SUBSTRING(maPhanCong,3,20) COLLATE Latin1_General_100_BIN2 NOT LIKE ''%[^0-9]%'' AND LEN(maPhanCong)=DATALENGTH(maPhanCong));
ELSE
    ALTER TABLE dbo.PhanCongCa WITH CHECK CHECK CONSTRAINT CK_GreenHome_PhanCongCa_Ma;

IF OBJECT_ID(N''dbo.CK_GreenHome_MaQuetSanPham_Tem'', N''C'') IS NULL
    ALTER TABLE dbo.MaQuetSanPham WITH CHECK ADD CONSTRAINT CK_GreenHome_MaQuetSanPham_Tem
        CHECK (LEN(LTRIM(RTRIM(maQuet)))>0);
ELSE
    ALTER TABLE dbo.MaQuetSanPham WITH CHECK CHECK CONSTRAINT CK_GreenHome_MaQuetSanPham_Tem;

IF OBJECT_ID(N''dbo.CK_GreenHome_PhieuDoiTra_LienHe'', N''C'') IS NULL
    ALTER TABLE dbo.PhieuDoiTra WITH CHECK ADD CONSTRAINT CK_GreenHome_PhieuDoiTra_LienHe
        CHECK (tenLienHe IS NOT NULL AND LEN(LTRIM(RTRIM(tenLienHe))) BETWEEN 2 AND 100 AND sdtLienHe IS NOT NULL AND DATALENGTH(sdtLienHe)=10 AND sdtLienHe COLLATE Latin1_General_100_BIN2 LIKE ''0[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'');
ELSE
    ALTER TABLE dbo.PhieuDoiTra WITH CHECK CHECK CONSTRAINT CK_GreenHome_PhieuDoiTra_LienHe;

IF OBJECT_ID(N''dbo.CK_GreenHome_PhieuDoiTra_HienTrang'', N''C'') IS NULL
    ALTER TABLE dbo.PhieuDoiTra WITH CHECK ADD CONSTRAINT CK_GreenHome_PhieuDoiTra_HienTrang
        CHECK (hienTrang IS NOT NULL AND LEN(LTRIM(RTRIM(hienTrang))) BETWEEN 2 AND 500 AND phuKien IS NOT NULL AND LEN(LTRIM(RTRIM(phuKien))) BETWEEN 2 AND 255);
ELSE
    ALTER TABLE dbo.PhieuDoiTra WITH CHECK CHECK CONSTRAINT CK_GreenHome_PhieuDoiTra_HienTrang;

IF OBJECT_ID(N''dbo.CK_GreenHome_ChiTietPhieuDoiTra_LyDo'', N''C'') IS NULL
    ALTER TABLE dbo.ChiTietPhieuDoiTra WITH CHECK ADD CONSTRAINT CK_GreenHome_ChiTietPhieuDoiTra_LyDo
        CHECK (lyDo IS NOT NULL AND LEN(LTRIM(RTRIM(lyDo))) BETWEEN 10 AND 500);
ELSE
    ALTER TABLE dbo.ChiTietPhieuDoiTra WITH CHECK CHECK CONSTRAINT CK_GreenHome_ChiTietPhieuDoiTra_LyDo;

IF OBJECT_ID(N''dbo.CK_GreenHome_ChiTietPhieuDoiTra_Gia'', N''C'') IS NULL
    ALTER TABLE dbo.ChiTietPhieuDoiTra WITH CHECK ADD CONSTRAINT CK_GreenHome_ChiTietPhieuDoiTra_Gia
        CHECK (giaTriGoc IS NULL OR giaTriGoc>=0);
ELSE
    ALTER TABLE dbo.ChiTietPhieuDoiTra WITH CHECK CHECK CONSTRAINT CK_GreenHome_ChiTietPhieuDoiTra_Gia;

IF OBJECT_ID(N''dbo.CK_GreenHome_ChiTietPhieuDoiTra_HangDoi'', N''C'') IS NULL
    ALTER TABLE dbo.ChiTietPhieuDoiTra WITH CHECK ADD CONSTRAINT CK_GreenHome_ChiTietPhieuDoiTra_HangDoi
        CHECK ((maSPThayThe IS NULL AND giaThayThe IS NULL) OR (hinhThucXuLy=''DOI_SAN_PHAM'' AND maSPThayThe IS NOT NULL AND giaThayThe IS NOT NULL AND giaThayThe>0));
ELSE
    ALTER TABLE dbo.ChiTietPhieuDoiTra WITH CHECK CHECK CONSTRAINT CK_GreenHome_ChiTietPhieuDoiTra_HangDoi;

IF OBJECT_ID(N''dbo.CK_GreenHome_LichSuDoiTra_SuKien'', N''C'') IS NULL
    ALTER TABLE dbo.LichSuDoiTra WITH CHECK ADD CONSTRAINT CK_GreenHome_LichSuDoiTra_SuKien
        CHECK (suKien IN (''TIEP_NHAN'',''GUI_LAI'',''DA_DUYET'',''TU_CHOI'',''HOAN_TAT''));
ELSE
    ALTER TABLE dbo.LichSuDoiTra WITH CHECK CHECK CONSTRAINT CK_GreenHome_LichSuDoiTra_SuKien;

IF OBJECT_ID(N''dbo.CK_GreenHome_LichSuDoiTra_HoanTat'', N''C'') IS NULL
    ALTER TABLE dbo.LichSuDoiTra WITH CHECK ADD CONSTRAINT CK_GreenHome_LichSuDoiTra_HoanTat
        CHECK (suKien<>''HOAN_TAT'' OR (phuongThuc IS NOT NULL AND phuongThuc IN (''TIEN_MAT'',''CHUYEN_KHOAN'') AND tienHoanDuKien IS NOT NULL AND tienHoanThucTe IS NOT NULL AND tienHoanThucTe BETWEEN 0 AND tienHoanDuKien AND chenhLechDoi IS NOT NULL));
ELSE
    ALTER TABLE dbo.LichSuDoiTra WITH CHECK CHECK CONSTRAINT CK_GreenHome_LichSuDoiTra_HoanTat;';
COMMIT TRANSACTION;
END TRY
BEGIN CATCH
IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
THROW;
END CATCH;
