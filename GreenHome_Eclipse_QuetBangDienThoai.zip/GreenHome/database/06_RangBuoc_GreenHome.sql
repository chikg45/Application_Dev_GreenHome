﻿-- Nâng cấp tại chỗ cho QuanLyBanHang sau bản quét mã và đổi trả.
-- Nếu bản ghi cũ vi phạm, xem tên bảng và ràng buộc ở Messages; không sửa dữ liệu tự động.
USE [QuanLyBanHang];
GO
IF DB_NAME() <> N'QuanLyBanHang' THROW 51006,N'Chọn đúng database QuanLyBanHang.',1;
SET XACT_ABORT ON;
BEGIN TRY
 BEGIN TRANSACTION;
EXEC sys.sp_executesql N'IF OBJECT_ID(N''dbo.CK_GreenHome_KhachHang_Ten'', N''C'') IS NULL
    ALTER TABLE dbo.KhachHang WITH CHECK ADD CONSTRAINT CK_GreenHome_KhachHang_Ten
        CHECK (LEN(LTRIM(RTRIM(tenKH))) BETWEEN 2 AND 50);
ELSE
    ALTER TABLE dbo.KhachHang WITH CHECK CHECK CONSTRAINT CK_GreenHome_KhachHang_Ten;

IF OBJECT_ID(N''dbo.CK_GreenHome_KhachHang_SDT'', N''C'') IS NULL
    ALTER TABLE dbo.KhachHang WITH CHECK ADD CONSTRAINT CK_GreenHome_KhachHang_SDT
        CHECK (DATALENGTH(sdtKH)=10 AND sdtKH COLLATE Latin1_General_100_BIN2 LIKE ''0[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'');
ELSE
    ALTER TABLE dbo.KhachHang WITH CHECK CHECK CONSTRAINT CK_GreenHome_KhachHang_SDT;

IF OBJECT_ID(N''dbo.CK_GreenHome_NhanVien_Ngay'', N''C'') IS NULL
    ALTER TABLE dbo.NhanVien WITH CHECK ADD CONSTRAINT CK_GreenHome_NhanVien_Ngay
        CHECK (ngaySinh<=DATEADD(year,-18,CONVERT(date,GETDATE())) AND ngayVaoLam BETWEEN ngaySinh AND CONVERT(date,GETDATE()));
ELSE
    ALTER TABLE dbo.NhanVien WITH CHECK CHECK CONSTRAINT CK_GreenHome_NhanVien_Ngay;

IF OBJECT_ID(N''dbo.CK_GreenHome_TaiKhoan_DangNhap'', N''C'') IS NULL
    ALTER TABLE dbo.TaiKhoan WITH CHECK ADD CONSTRAINT CK_GreenHome_TaiKhoan_DangNhap
        CHECK (DATALENGTH(tenDangNhap) BETWEEN 4 AND 30 AND tenDangNhap COLLATE Latin1_General_100_BIN2 NOT LIKE ''%[^A-Za-z0-9_]%'' AND LEN(tenDangNhap)=DATALENGTH(tenDangNhap));
ELSE
    ALTER TABLE dbo.TaiKhoan WITH CHECK CHECK CONSTRAINT CK_GreenHome_TaiKhoan_DangNhap;

IF OBJECT_ID(N''dbo.CK_GreenHome_SanPham_Ma'', N''C'') IS NULL
    ALTER TABLE dbo.SanPham WITH CHECK ADD CONSTRAINT CK_GreenHome_SanPham_Ma
        CHECK (LEN(LTRIM(RTRIM(maSP)))>0);
ELSE
    ALTER TABLE dbo.SanPham WITH CHECK CHECK CONSTRAINT CK_GreenHome_SanPham_Ma;

IF OBJECT_ID(N''dbo.CK_GreenHome_SanPham_TonBan'', N''C'') IS NULL
    ALTER TABLE dbo.SanPham WITH CHECK ADD CONSTRAINT CK_GreenHome_SanPham_TonBan
        CHECK ((tinhTrang=''NGUNG_KINH_DOANH'' OR (tinhTrang=''HET_HANG'' AND soLuongTon=soLuongLoi) OR (tinhTrang=''DANG_KINH_DOANH'' AND soLuongTon>soLuongLoi)));
ELSE
    ALTER TABLE dbo.SanPham WITH CHECK CHECK CONSTRAINT CK_GreenHome_SanPham_TonBan;

IF OBJECT_ID(N''dbo.CK_GreenHome_KhuyenMai_Ten'', N''C'') IS NULL
    ALTER TABLE dbo.KhuyenMai WITH CHECK ADD CONSTRAINT CK_GreenHome_KhuyenMai_Ten
        CHECK (LEN(LTRIM(RTRIM(tenKM))) BETWEEN 2 AND 100);
ELSE
    ALTER TABLE dbo.KhuyenMai WITH CHECK CHECK CONSTRAINT CK_GreenHome_KhuyenMai_Ten;

IF OBJECT_ID(N''dbo.CK_GreenHome_KhuyenMai_MucGiam'', N''C'') IS NULL
    ALTER TABLE dbo.KhuyenMai WITH CHECK ADD CONSTRAINT CK_GreenHome_KhuyenMai_MucGiam
        CHECK ((loaiGiam=''PHAN_TRAM'' AND phanTramGiam>0 AND phanTramGiam<=100 AND soTienGiam=0) OR (loaiGiam=''SO_TIEN'' AND phanTramGiam=0 AND soTienGiam>0));
ELSE
    ALTER TABLE dbo.KhuyenMai WITH CHECK CHECK CONSTRAINT CK_GreenHome_KhuyenMai_MucGiam;

IF OBJECT_ID(N''dbo.CK_GreenHome_CaLamViec_Ten'', N''C'') IS NULL
    ALTER TABLE dbo.CaLamViec WITH CHECK ADD CONSTRAINT CK_GreenHome_CaLamViec_Ten
        CHECK (LEN(LTRIM(RTRIM(tenCa))) BETWEEN 2 AND 50);
ELSE
    ALTER TABLE dbo.CaLamViec WITH CHECK CHECK CONSTRAINT CK_GreenHome_CaLamViec_Ten;

IF OBJECT_ID(N''dbo.CK_GreenHome_PhanCongCa_Ma'', N''C'') IS NULL
    ALTER TABLE dbo.PhanCongCa WITH CHECK ADD CONSTRAINT CK_GreenHome_PhanCongCa_Ma
        CHECK (DATALENGTH(maPhanCong) BETWEEN 5 AND 10 AND LEFT(maPhanCong,2) COLLATE Latin1_General_100_BIN2=''PC'' AND SUBSTRING(maPhanCong,3,20) COLLATE Latin1_General_100_BIN2 NOT LIKE ''%[^0-9]%'' AND LEN(maPhanCong)=DATALENGTH(maPhanCong));
ELSE
    ALTER TABLE dbo.PhanCongCa WITH CHECK CHECK CONSTRAINT CK_GreenHome_PhanCongCa_Ma;

IF OBJECT_ID(N''dbo.CK_GreenHome_MaQuetSanPham_Tem'', N''C'') IS NULL
    ALTER TABLE dbo.MaQuetSanPham WITH CHECK ADD CONSTRAINT CK_GreenHome_MaQuetSanPham_Tem
        CHECK (LEN(LTRIM(RTRIM(maQuet)))>0);
ELSE
    ALTER TABLE dbo.MaQuetSanPham WITH CHECK CHECK CONSTRAINT CK_GreenHome_MaQuetSanPham_Tem;

IF OBJECT_ID(N''dbo.CK_GreenHome_PhieuDoiTra_LienHe'', N''C'') IS NULL
    ALTER TABLE dbo.PhieuDoiTra WITH CHECK ADD CONSTRAINT CK_GreenHome_PhieuDoiTra_LienHe
        CHECK (tenLienHe IS NOT NULL AND LEN(LTRIM(RTRIM(tenLienHe))) BETWEEN 2 AND 100 AND sdtLienHe IS NOT NULL AND DATALENGTH(sdtLienHe)=10 AND sdtLienHe COLLATE Latin1_General_100_BIN2 LIKE ''0[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'');
ELSE
    ALTER TABLE dbo.PhieuDoiTra WITH CHECK CHECK CONSTRAINT CK_GreenHome_PhieuDoiTra_LienHe;

IF OBJECT_ID(N''dbo.CK_GreenHome_PhieuDoiTra_HienTrang'', N''C'') IS NULL
    ALTER TABLE dbo.PhieuDoiTra WITH CHECK ADD CONSTRAINT CK_GreenHome_PhieuDoiTra_HienTrang
        CHECK (hienTrang IS NOT NULL AND LEN(LTRIM(RTRIM(hienTrang))) BETWEEN 2 AND 500 AND phuKien IS NOT NULL AND LEN(LTRIM(RTRIM(phuKien))) BETWEEN 2 AND 255);
ELSE
    ALTER TABLE dbo.PhieuDoiTra WITH CHECK CHECK CONSTRAINT CK_GreenHome_PhieuDoiTra_HienTrang;

IF OBJECT_ID(N''dbo.CK_GreenHome_ChiTietPhieuDoiTra_LyDo'', N''C'') IS NULL
    ALTER TABLE dbo.ChiTietPhieuDoiTra WITH CHECK ADD CONSTRAINT CK_GreenHome_ChiTietPhieuDoiTra_LyDo
        CHECK (lyDo IS NOT NULL AND LEN(LTRIM(RTRIM(lyDo))) BETWEEN 10 AND 500);
ELSE
    ALTER TABLE dbo.ChiTietPhieuDoiTra WITH CHECK CHECK CONSTRAINT CK_GreenHome_ChiTietPhieuDoiTra_LyDo;

IF OBJECT_ID(N''dbo.CK_GreenHome_ChiTietPhieuDoiTra_Gia'', N''C'') IS NULL
    ALTER TABLE dbo.ChiTietPhieuDoiTra WITH CHECK ADD CONSTRAINT CK_GreenHome_ChiTietPhieuDoiTra_Gia
        CHECK (giaTriGoc IS NULL OR giaTriGoc>=0);
ELSE
    ALTER TABLE dbo.ChiTietPhieuDoiTra WITH CHECK CHECK CONSTRAINT CK_GreenHome_ChiTietPhieuDoiTra_Gia;

IF OBJECT_ID(N''dbo.CK_GreenHome_ChiTietPhieuDoiTra_HangDoi'', N''C'') IS NULL
    ALTER TABLE dbo.ChiTietPhieuDoiTra WITH CHECK ADD CONSTRAINT CK_GreenHome_ChiTietPhieuDoiTra_HangDoi
        CHECK ((maSPThayThe IS NULL AND giaThayThe IS NULL) OR (hinhThucXuLy=''DOI_SAN_PHAM'' AND maSPThayThe IS NOT NULL AND giaThayThe IS NOT NULL AND giaThayThe>0));
ELSE
    ALTER TABLE dbo.ChiTietPhieuDoiTra WITH CHECK CHECK CONSTRAINT CK_GreenHome_ChiTietPhieuDoiTra_HangDoi;

IF OBJECT_ID(N''dbo.CK_GreenHome_LichSuDoiTra_SuKien'', N''C'') IS NULL
    ALTER TABLE dbo.LichSuDoiTra WITH CHECK ADD CONSTRAINT CK_GreenHome_LichSuDoiTra_SuKien
        CHECK (suKien IN (''TIEP_NHAN'',''GUI_LAI'',''DA_DUYET'',''TU_CHOI'',''HOAN_TAT''));
ELSE
    ALTER TABLE dbo.LichSuDoiTra WITH CHECK CHECK CONSTRAINT CK_GreenHome_LichSuDoiTra_SuKien;

IF OBJECT_ID(N''dbo.CK_GreenHome_LichSuDoiTra_HoanTat'', N''C'') IS NULL
    ALTER TABLE dbo.LichSuDoiTra WITH CHECK ADD CONSTRAINT CK_GreenHome_LichSuDoiTra_HoanTat
        CHECK (suKien<>''HOAN_TAT'' OR (phuongThuc IS NOT NULL AND phuongThuc IN (''TIEN_MAT'',''CHUYEN_KHOAN'') AND tienHoanDuKien IS NOT NULL AND tienHoanThucTe IS NOT NULL AND tienHoanThucTe BETWEEN 0 AND tienHoanDuKien AND chenhLechDoi IS NOT NULL));
ELSE
    ALTER TABLE dbo.LichSuDoiTra WITH CHECK CHECK CONSTRAINT CK_GreenHome_LichSuDoiTra_HoanTat;';
 COMMIT;
 PRINT N'Đã đồng bộ ràng buộc GreenHome.';
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK;
 THROW;
END CATCH;
