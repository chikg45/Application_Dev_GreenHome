package dao;

import database.DatabaseConnection;
import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;
import static connectDB.Jdbc.capNhat;

/** Ghi nhận bàn giao tại quầy. Khóa phiếu và đọc lại giá, tồn trước khi ghi sổ. */
public final class GiaoDichDoiTraDAO {
    public record SanPhamThay(String ma, String ten, BigDecimal gia, int ton) {
        public String toString() { return ma + " · " + ten + " · " + gia.toPlainString() + " đ · còn " + ton; }
    }
    public record SuKien(String loai, String nguoi, LocalDateTime luc, BigDecimal duKien,
                         BigDecimal thucHoan, BigDecimal chenh, String phuongThuc) {}
    public List<SanPhamThay> sanPhamThay() throws SQLException {
        String sql = "SELECT maSP,tenSP,giaNiemYet,soLuongTon-soLuongLoi FROM dbo.SanPham " +
                "WHERE tinhTrang='DANG_KINH_DOANH' AND soLuongTon>soLuongLoi ORDER BY tenSP,maSP";
        List<SanPhamThay> ds = new ArrayList<>();
        try (Connection c=DatabaseConnection.getConnection(); Statement st=c.createStatement(); ResultSet r=st.executeQuery(sql)) {
            while(r.next()) ds.add(new SanPhamThay(r.getString(1),r.getString(2),r.getBigDecimal(3),r.getInt(4)));
        }
        return ds;
    }
    public List<SuKien> lichSu(String ma) throws SQLException {
        List<SuKien> ds=new ArrayList<>();
        String sql="SELECT l.suKien,n.hoTen,l.thoiDiem,l.tienHoanDuKien,l.tienHoanThucTe,l.chenhLechDoi,l.phuongThuc " +
                "FROM dbo.LichSuDoiTra l JOIN dbo.NhanVien n ON l.maNV=n.maNV WHERE maPhieu=? ORDER BY l.id";
        try(Connection c=DatabaseConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql)) {
            p.setString(1,ma);
            try(ResultSet r=p.executeQuery()) {
                while(r.next()) ds.add(new SuKien(r.getString(1),r.getString(2),r.getTimestamp(3)==null?null:r.getTimestamp(3).toLocalDateTime(),
                        r.getBigDecimal(4),r.getBigDecimal(5),r.getBigDecimal(6),r.getString(7)));
            }
        }
        return ds;
    }

    public void hoanTat(String ma, String nv, Map<Integer,SanPhamThay> thay, BigDecimal hoan,
                        BigDecimal duKien, BigDecimal chenh, String pt) throws SQLException {
        try(Connection c=DatabaseConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                DoiTraDAO.yeuCauVaiTro(c,nv,false);
                if(capNhat(c,"UPDATE dbo.PhieuDoiTra SET trangThaiDuyet='HOAN_TAT' WHERE maPhieuDoiTra=? " +
                        "AND maNV=? AND trangThaiDuyet='DA_DUYET'",ma,nv)!=1)
                    throw new IllegalArgumentException("Phiếu đã được xử lý, chưa được duyệt hoặc thuộc nhân viên khác.");
                List<DoiTraDAO.DongTraInfo> rows=new ArrayList<>();
                try(PreparedStatement p=c.prepareStatement("SELECT idChiTietHD,soLuong,hinhThucXuLy,donGia,COALESCE(giaTriGoc,donGia*soLuong) " +
                        "FROM dbo.ChiTietPhieuDoiTra WITH (UPDLOCK,HOLDLOCK) WHERE maPhieuDoiTra=? ORDER BY idChiTietHD")) {
                    p.setString(1,ma);
                    try(ResultSet r=p.executeQuery()) {
                        while(r.next()) rows.add(new DoiTraDAO.DongTraInfo(r.getInt(1),r.getInt(2),r.getString(3),
                                null,null,null,r.getBigDecimal(4),null,null,r.getBigDecimal(5)));
                    }
                }
                var tong=bus.DoiTraBUS.tinhGiaoDich(rows,thay);
                if(tong.hoan().compareTo(duKien)!=0 || tong.chenh().compareTo(chenh)!=0)
                    throw new IllegalArgumentException("Số tiền của phiếu đã thay đổi. Mở lại phiếu để xác nhận.");
                bus.DoiTraBUS.kiemTraHoan(hoan,tong.hoan(),pt);
                for(var row:rows) {
                    if(!"DOI_SAN_PHAM".equals(row.xuLy())) continue;
                    var sp=thay.get(row.idChiTietHD());
                    if(capNhat(c,"UPDATE dbo.SanPham SET soLuongTon=soLuongTon-?, "
                        + "tinhTrang=CASE WHEN soLuongTon-soLuongLoi=? THEN 'HET_HANG' ELSE tinhTrang END WHERE maSP=? " +
                            "AND tinhTrang='DANG_KINH_DOANH' AND giaNiemYet=? AND soLuongTon-soLuongLoi>=?",
                            row.soLuong(),row.soLuong(),sp.ma(),sp.gia(),row.soLuong())!=1)
                        throw new IllegalArgumentException("Giá, trạng thái hoặc tồn của "+sp.ma()+" đã thay đổi. Chọn lại hàng.");
                    if(capNhat(c,"UPDATE dbo.ChiTietPhieuDoiTra SET maSPThayThe=?,giaThayThe=? " +
                            "WHERE maPhieuDoiTra=? AND idChiTietHD=?",sp.ma(),sp.gia(),ma,row.idChiTietHD())!=1)
                        throw new SQLException("Thiếu dòng đổi hàng.");
                }
                capNhat(c,"INSERT dbo.LichSuDoiTra(maPhieu,suKien,maNV,tienHoanDuKien,tienHoanThucTe,chenhLechDoi,phuongThuc) " +
                        "VALUES (?,'HOAN_TAT',?,?,?,?,?)",ma,nv,tong.hoan(),hoan,tong.chenh(),pt);
                c.commit();
            } catch(SQLException | RuntimeException ex) { c.rollback(); throw ex; }
        }
    }
}
