package ui;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.JTextComponent;
import util.HoTroPhimTat;
import util.QuanLyHoanTac;

public class MainFrame extends JFrame {

    private static final Color BG = GreenTheme.CANVAS;
    private static final Color SIDE = GreenTheme.SURFACE;
    private static final Color CARD = GreenTheme.SURFACE;
    private static final Color BORDER = GreenTheme.BORDER;
    private static final Color TEXT = GreenTheme.TEXT;
    private static final Color MUTED = GreenTheme.MUTED;
    private static final Color ACCENT = GreenTheme.ACCENT;
    private static final Color GREEN = GreenTheme.GREEN;
    private static final Color GOLD = GreenTheme.GOLD;
    private static final Color RED = GreenTheme.RED;

    private final String tenNguoiDung;
    private final boolean laQuanLy;
    private final CardLayout cardLayout = new CardLayout();
    private final JPanel cardPanel = new JPanel(cardLayout);
    private final Map<String, JButton> menuButtons = new LinkedHashMap<>();
    private final Map<String, JPanel> pages = new LinkedHashMap<>();
    private final java.util.Set<String> pagesDaMo = new java.util.HashSet<>();
    private final JLabel lblPageTitle = label("Tổng quan", 17, Font.BOLD, TEXT);

    public MainFrame(String tenNguoiDung, boolean laQuanLy) {
        this.tenNguoiDung = tenNguoiDung;
        this.laQuanLy = laQuanLy;
        GreenTheme.install();
        setTitle("Green Home - Quản lý bán hàng");
        setSize(1360, 860);
        setMinimumSize(new Dimension(1000, 650));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initComponents();
        dangKyPhimTatToanCuc();
        showPage("Tổng quan");
    }

    private void initComponents() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG);
        root.add(createSidebar(), BorderLayout.WEST);
        root.add(createMainArea(), BorderLayout.CENTER);
        setContentPane(root);
    }

    // ==================== PHÍM TẮT TOÀN CỤC ====================

    private void dangKyPhimTatToanCuc() {
        JRootPane root = getRootPane();
        InputMap im = root.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap am = root.getActionMap();

        // F1: Mở hướng dẫn theo màn hình hiện tại
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0), "MO_HUONG_DAN");
        am.put("MO_HUONG_DAN", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                moHuongDanTheoTab();
            }
        });

        // Ctrl + Z: Hoàn tác hành động vừa làm
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_Z, InputEvent.CTRL_DOWN_MASK), "HOAN_TAC");
        am.put("HOAN_TAC", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Component focus = KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner();
                if (focus instanceof JTextComponent) {
                    return; // Nhường Ctrl+Z mặc định khi đang gõ trong ô text
                }
                QuanLyHoanTac.hoanTacGanNhat(MainFrame.this);
            }
        });

        // Ctrl + N: Thêm mới / Đơn mới
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK), "THEM_MOI");
        am.put("THEM_MOI", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goiHanhDongTabHienTai("THEM_MOI");
            }
        });

        // Ctrl + F: Tìm kiếm nhanh
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_DOWN_MASK), "TIM_KIEM");
        am.put("TIM_KIEM", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goiHanhDongTabHienTai("TIM_KIEM");
            }
        });

        // F5: Làm mới dữ liệu
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0), "LAM_MOI");
        am.put("LAM_MOI", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goiHanhDongTabHienTai("LAM_MOI");
            }
        });

        // Delete: Xóa dòng đang chọn (khi không đứng trong ô gõ chữ)
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0), "XOA_MUC");
        am.put("XOA_MUC", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Component focus = KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner();
                if (focus instanceof JTextComponent) {
                    return;
                }
                goiHanhDongTabHienTai("XOA_MUC");
            }
        });

        // Ctrl + S hoặc F9: Thanh toán / Xuất báo cáo / Lưu
        KeyStroke ksSave = KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK);
        KeyStroke ksF9 = KeyStroke.getKeyStroke(KeyEvent.VK_F9, 0);
        im.put(ksSave, "LUU_THANH_TOAN");
        im.put(ksF9, "LUU_THANH_TOAN");
        am.put("LUU_THANH_TOAN", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goiHanhDongTabHienTai("LUU_THANH_TOAN");
            }
        });

        // Ctrl + 1..9: Chuyển nhanh giữa các tab
        String[] danhSachTab = {
            "Tổng quan", "Bán hàng", "Khách hàng", "Sản phẩm",
            "Khuyến mãi", "Đổi / trả", "Lịch làm việc", "Thống kê", "Nhân viên & tài khoản"
        };
        for (int i = 0; i < danhSachTab.length; i++) {
            final String tenTab = danhSachTab[i];
            int keyCode = KeyEvent.VK_1 + i;
            im.put(KeyStroke.getKeyStroke(keyCode, InputEvent.CTRL_DOWN_MASK), "CHUYEN_TAB_" + i);
            am.put("CHUYEN_TAB_" + i, new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (menuButtons.containsKey(tenTab)) {
                        showPage(tenTab);
                    }
                }
            });
        }
    }

    private void goiHanhDongTabHienTai(String hanhDong) {
        String tabHienTai = lblPageTitle.getText();
        JPanel page = pages.get(tabHienTai);
        if (page == null) return;

        if (page instanceof HoTroPhimTat ht) {
            switch (hanhDong) {
                case "THEM_MOI" -> ht.phimThemMoi();
                case "TIM_KIEM" -> ht.phimTimKiem();
                case "LAM_MOI" -> ht.phimLamMoi();
                case "XOA_MUC" -> ht.phimXoa();
                case "LUU_THANH_TOAN" -> ht.phimLuuHoacThanhToan();
            }
            return;
        }

        // Hỗ trợ tự động cho các tab còn lại (Bán hàng, Khách hàng, Khuyến mãi, Đổi/trả, Lịch, Thống kê)
        switch (hanhDong) {
            case "TIM_KIEM" -> {
                JTextField tf = timTextFieldDauTien(page);
                if (tf != null) {
                    tf.requestFocusInWindow();
                    tf.selectAll();
                }
            }
            case "THEM_MOI" -> {
                if (page instanceof BanHangPanel) clickNutTheoTuKhoa(page, "Đơn mới");
                else clickNutTheoTuKhoa(page, "+ ", "Thêm", "Tiếp nhận", "Phân công");
            }
            case "LAM_MOI" -> {
                if (page instanceof HoaDonPanel hd) hd.lamMoiDuLieu();
                else if (page instanceof BanHangPanel bh) bh.lamMoiDuLieu();
                else if (page instanceof KhachHangPanel kh) kh.lamMoiTuCSDL();
                else if (page instanceof DoiTraPanel dt) dt.lamMoiTuCSDL();
                else if (page instanceof LichLamViecPanel lich) lich.lamMoiTuCSDL();
                else if (page instanceof ThongKePanel tk) tk.lamMoiDuLieu();
            }
            case "LUU_THANH_TOAN" -> clickNutTheoTuKhoa(page, "Thanh toán", "Xuất", "Lưu");
        }
    }

    private JTextField timTextFieldDauTien(Container root) {
        for (Component c : root.getComponents()) {
            if (c instanceof JTextField tf && tf.isVisible() && tf.isEditable()) {
                return tf;
            }
            if (c instanceof Container child) {
                JTextField found = timTextFieldDauTien(child);
                if (found != null) return found;
            }
        }
        return null;
    }

    private boolean clickNutTheoTuKhoa(Container root, String... keywords) {
        for (Component c : root.getComponents()) {
            if (c instanceof JButton btn && btn.isVisible() && btn.isEnabled() && btn.getText() != null) {
                String text = btn.getText();
                for (String kw : keywords) {
                    if (text.contains(kw)) {
                        btn.doClick();
                        return true;
                    }
                }
            }
            if (c instanceof Container child && clickNutTheoTuKhoa(child, keywords)) {
                return true;
            }
        }
        return false;
    }

    private void moHuongDanTheoTab() {
        String tab = lblPageTitle.getText();
        String tieuDe = "Hướng dẫn sử dụng - " + tab;
        String noiDung = switch (tab) {
            case "Bán hàng" -> """
                HƯỚNG DẪN BÁN HÀNG & THANH TOÁN:
                1. Tìm sản phẩm theo tên/mã ở khung bên trái (hoặc bấm Ctrl + F) rồi bấm [+ Thêm].
                2. Tìm khách hàng theo SĐT ở khung trên bên phải, hoặc chọn [Khách vãng lai]. [+ Khách mới] mở trang Khách hàng, lưu xong sẽ quay lại giỏ.
                3. Điều chỉnh số lượng (+/-) trong giỏ hàng; nếu lỡ xóa nhầm món, bấm Ctrl + Z để khôi phục.
                4. Tích chọn dùng điểm tích lũy (nếu có), sau đó bấm [Thanh toán] (hoặc Ctrl + S / F9) để xuất hóa đơn.
                """;
            case "Hóa đơn" -> "Tìm hóa đơn theo mã, tên hoặc số điện thoại khách hàng. Chọn Xem / In để đọc chi tiết hoặc in hóa đơn.";
            case "Khách hàng" -> """
                HƯỚNG DẪN QUẢN LÝ KHÁCH HÀNG:
                1. Bấm [+ Thêm khách hàng] (hoặc Ctrl + N) để tạo hồ sơ khách hàng mới.
                2. Nhập tên hoặc SĐT vào ô tìm kiếm (Ctrl + F) để tra cứu nhanh.
                3. Bấm [Xem] trên từng dòng để xem chi tiết lịch sử hóa đơn và điểm tích lũy, hoặc [Sửa] để cập nhật.
                """;
            case "Sản phẩm" -> """
                HƯỚNG DẪN QUẢN LÝ SẢN PHẨM:
                1. Bấm [+ Thêm sản phẩm] (Ctrl + N) để thêm mặt hàng mới, hoặc [Nhập Excel] / [Cộng tồn Excel] để nhập hàng loạt.
                2. Chọn 1 dòng trên bảng để [Sửa], [Xóa] (phím Delete) hoặc [Ngừng / Mở lại kinh doanh].
                3. Nếu lỡ xóa nhầm, sửa nhầm hoặc ngừng bán nhầm sản phẩm: click ra vùng bảng và bấm Ctrl + Z để hoàn tác ngay lập tức.
                """;
            case "Khuyến mãi" -> """
                HƯỚNG DẪN QUẢN LÝ KHUYẾN MÃI:
                1. Bấm [+ Thêm khuyến mãi] (Ctrl + N), thiết lập mức giảm (% hoặc số tiền), thời gian áp dụng và chọn danh sách sản phẩm.
                2. Chọn chương trình trên bảng để [Xem chi tiết], [Sửa] hoặc [Xóa].
                """;
            case "Đổi / trả" -> """
                HƯỚNG DẪN XỬ LÝ ĐỔI / TRẢ HÀNG (TRONG 7 NGÀY):
                1. Nhân viên bấm [+ Tiếp nhận đổi / trả] (Ctrl + N), tìm hóa đơn gốc còn trong hạn 7 ngày.
                2. Chọn sản phẩm cần đổi/trả, nhập lý do, tình trạng sản phẩm và gửi Quản lý phê duyệt.
                3. Quản lý mở phiếu ở trạng thái Chờ duyệt để bấm [Phê duyệt] hoặc [Từ chối].
                """;
            case "Lịch làm việc" -> """
                HƯỚNG DẪN LỊCH LÀM VIỆC:
                1. Dùng nút [‹], [›] hoặc [Tuần này] để chuyển tuần xem lịch phân công.
                2. Quản lý bấm [+ Phân công ca] (Ctrl + N) hoặc bấm dấu [+] ngay tại ô ngày của nhân viên để xếp ca Sáng / Chiều / Tối.
                """;
            case "Thống kê" -> """
                HƯỚNG DẪN THỐNG KÊ DOANH THU:
                1. Chọn khoảng thời gian Từ ngày – Đến ngày và bấm [Áp dụng] (hoặc [Tháng này]).
                2. Chuyển đổi giữa các tab Doanh thu, Sản phẩm bán chạy, Đổi/trả để xem biểu đồ.
                3. Bấm [Xuất CSV] (hoặc Ctrl + S) để lưu báo cáo ra file.
                """;
            case "Nhân viên & tài khoản" -> """
                HƯỚNG DẪN QUẢN LÝ NHÂN VIÊN & TÀI KHOẢN:
                1. Bấm [+ Thêm nhân viên] (Ctrl + N) để tạo hồ sơ và cấp tài khoản đăng nhập (mật khẩu mặc định 123456).
                2. Bấm [Sửa] để cập nhật thông tin, vai trò hoặc trạng thái làm việc.
                3. Bấm [Khóa / Mở khóa] để tạm ngừng quyền đăng nhập. Nếu lỡ khóa hoặc sửa nhầm, bấm Ctrl + Z để hoàn tác.
                """;
            default -> """
                HƯỚNG DẪN SỬ DỤNG CHUNG - GREEN HOME:
                • Chuyển nhanh giữa các chức năng: Ctrl + 1 đến Ctrl + 9
                • Thêm mới dữ liệu ở màn hình đang mở: Ctrl + N
                • Đưa con trỏ vào ô tìm kiếm: Ctrl + F
                • Tải lại dữ liệu mới nhất từ SQL Server: F5
                • Xóa mục đang chọn: Delete
                • Thanh toán / Xuất báo cáo: Ctrl + S hoặc F9
                • Hoàn tác thao tác vừa làm (xóa/sửa/khóa nhầm): Ctrl + Z
                • Xem hướng dẫn của từng màn hình: F1
                """;
        };

        JTextArea area = new JTextArea(noiDung);
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setFont(new Font("SansSerif", Font.PLAIN, 13));
        area.setBackground(GreenTheme.SOFT);
        area.setForeground(TEXT);
        area.setBorder(new EmptyBorder(12, 14, 12, 14));

        JScrollPane scroll = new JScrollPane(area);
        scroll.setPreferredSize(new Dimension(540, 260));
        scroll.setBorder(BorderFactory.createLineBorder(BORDER));

        JOptionPane.showMessageDialog(this, scroll, tieuDe, JOptionPane.INFORMATION_MESSAGE);
    }

    // ==================== SIDEBAR ====================

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setBackground(SIDE);
        sidebar.setPreferredSize(new Dimension(214, 0));
        sidebar.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, BORDER));

        JPanel brand = new JPanel(new BorderLayout(10, 0));
        brand.setOpaque(false);
        brand.setBorder(new EmptyBorder(21, 15, 20, 14));
        brand.add(new Avatar("G", GreenTheme.GREEN, 34, 9), BorderLayout.WEST);
        JPanel brandText = vertical();
        brandText.add(label("GREEN HOME", 13, Font.BOLD, TEXT));
        brandText.add(Box.createVerticalStrut(3));
        brandText.add(label("ĐIỆN MÁY CHO MỌI NHÀ", 8, Font.PLAIN, MUTED));
        brand.add(brandText, BorderLayout.CENTER);
        sidebar.add(brand, BorderLayout.NORTH);

        JPanel navigation = vertical();
        navigation.setBorder(new EmptyBorder(12, 10, 10, 10));
        navigation.add(label("  NGHIỆP VỤ CỬA HÀNG", 10, Font.BOLD, MUTED));
        navigation.add(Box.createVerticalStrut(14));
        addMenu(navigation, "Tổng quan", "grid");
        addMenu(navigation, "Bán hàng", "cart");
        addMenu(navigation, "Hóa đơn", "history");
        addMenu(navigation, "Khách hàng", "users");
        addMenu(navigation, "Sản phẩm", "box");
        addMenu(navigation, "Khuyến mãi", "tag");
        addMenu(navigation, "Đổi / trả", "return");
        addMenu(navigation, "Lịch làm việc", "calendar");
        if (laQuanLy) {
            addMenu(navigation, "Thống kê", "chart");
            addMenu(navigation, "Nhân viên & tài khoản", "users");
        }
        navigation.add(Box.createVerticalGlue());
        sidebar.add(navigation, BorderLayout.CENTER);

        JPanel footer = vertical();
        footer.setBorder(new EmptyBorder(6, 11, 15, 11));

        // Thay thế cụm Lịch hôm nay / Quy trình nghiệp vụ / Nhật ký thao tác bằng nút Hướng dẫn
        footer.add(footerButton("Hướng dẫn sử dụng (F1)", "help", this::moHuongDanTheoTab));
        footer.add(Box.createVerticalStrut(10));
        JSeparator line = new JSeparator();
        line.setForeground(BORDER);
        line.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        line.setAlignmentX(Component.LEFT_ALIGNMENT);
        footer.add(line);
        footer.add(Box.createVerticalStrut(13));

        JPanel account = new JPanel(new BorderLayout(10, 0));
        account.setOpaque(false);
        account.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        account.add(new Avatar(initials(tenNguoiDung), GreenTheme.ACCENT, 34, 12), BorderLayout.WEST);
        JPanel accountText = vertical();
        JLabel accountName = label(tenNguoiDung, 11, Font.BOLD, TEXT);
        accountName.setToolTipText(tenNguoiDung);
        accountText.add(accountName);
        accountText.add(Box.createVerticalStrut(3));
        accountText.add(label(laQuanLy ? "Quản lý" : "Nhân viên bán hàng", 9, Font.PLAIN, MUTED));
        account.add(accountText, BorderLayout.CENTER);
        JButton logout = new JButton(new UiIcon("logout", MUTED, 16));
        logout.setToolTipText("Đăng xuất");
        logout.setForeground(MUTED);
        logout.setBorderPainted(false);
        logout.setContentAreaFilled(false);
        logout.setFocusPainted(false);
        logout.addActionListener(e -> logout());
        account.add(logout, BorderLayout.EAST);
        account.setAlignmentX(Component.LEFT_ALIGNMENT);
        footer.add(account);
        sidebar.add(footer, BorderLayout.SOUTH);
        return sidebar;
    }

    private void addMenu(JPanel navigation, String name, String icon) {
        JButton button = new JButton(name, new UiIcon(icon, MUTED, 17));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setIconTextGap(12);
        button.setFont(new Font("SansSerif", Font.PLAIN, 12));
        button.setForeground(MUTED);
        button.setBackground(SIDE);
        button.setFocusPainted(false);
        button.setOpaque(true);
        button.setBorder(new EmptyBorder(0, 12, 0, 7));
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 37));
        button.setPreferredSize(new Dimension(190, 37));
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.addActionListener(e -> showPage(name));
        navigation.add(button);
        navigation.add(Box.createVerticalStrut(3));
        menuButtons.put(name, button);
        JPanel initial;
        if ("Tổng quan".equals(name)) {
            initial = createDashboard();
            pagesDaMo.add(name);
        } else {
            initial = new JPanel();
            initial.setBackground(BG);
        }
        pages.put(name, initial);
        cardPanel.add(initial, name);
    }

    private JPanel footerButton(String text, String icon, Runnable action) {
        JButton button = new JButton(text, new UiIcon(icon, GreenTheme.ACCENT, 15));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setIconTextGap(10);
        button.setFont(new Font("SansSerif", Font.BOLD, 11));
        button.setForeground(GreenTheme.ACCENT);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setBorder(new EmptyBorder(8, 6, 8, 6));
        button.addActionListener(e -> action.run());

        RoundedPanel row = rounded(GreenTheme.TINT, GreenTheme.TINT, 10);
        row.setLayout(new BorderLayout());
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        row.add(button, BorderLayout.CENTER);
        return row;
    }

    // ==================== KHUNG CHINH ====================

    private JPanel createMainArea() {
        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(BG);
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(SIDE);
        header.setBorder(new EmptyBorder(10, 22, 10, 22));
        header.setPreferredSize(new Dimension(0, 65));
        JPanel headerLeft = vertical();
        headerLeft.add(label("Green Home  /  " + (laQuanLy ? "Quản lý" : "Nhân viên bán hàng"),
                10, Font.PLAIN, MUTED));
        headerLeft.add(Box.createVerticalStrut(4));
        headerLeft.add(lblPageTitle);
        header.add(headerLeft, BorderLayout.WEST);
        JPanel headerRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 4));
        headerRight.setOpaque(false);
        headerRight.add(label(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")), 11, Font.PLAIN, MUTED));
        JButton logout = new JButton(new UiIcon("logout", MUTED, 17));
        logout.setFocusPainted(false);
        logout.setContentAreaFilled(false);
        logout.setBorderPainted(false);
        logout.setBorder(new EmptyBorder(6, 7, 6, 7));
        logout.setToolTipText("Đăng xuất");
        logout.addActionListener(e -> logout());
        headerRight.add(logout);
        header.add(headerRight, BorderLayout.EAST);
        main.add(header, BorderLayout.NORTH);
        cardPanel.setBackground(BG);
        main.add(cardPanel, BorderLayout.CENTER);
        return main;
    }

    // ==================== DASHBOARD ====================

    private JPanel createDashboard() {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(BG);
        JPanel content = vertical();
        content.setBorder(new EmptyBorder(24, 28, 25, 28));

        JPanel welcome = new JPanel(new BorderLayout(10, 0));
        welcome.setOpaque(false);
        JPanel greeting = vertical();
        greeting.add(label("Xin chào, " + tenNguoiDung, 21, Font.BOLD, TEXT));
        greeting.add(Box.createVerticalStrut(6));
        greeting.add(label("Theo dõi hoạt động cửa hàng và các công việc cần xử lý.", 12, Font.PLAIN, MUTED));
        welcome.add(greeting, BorderLayout.WEST);

        // Đã bỏ nút "Quy trình nghiệp vụ" ở góc trên bên phải
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 7, 0));
        actions.setOpaque(false);
        actions.add(primaryButton("Bán hàng", "cart", () -> {
            if (menuButtons.containsKey("Bán hàng")) showPage("Bán hàng");
            else info("Bán hàng - chỉ dành cho nhân viên bán hàng");
        }));
        welcome.add(actions, BorderLayout.EAST);
        content.add(welcome);
        content.add(Box.createVerticalStrut(17));

        RoundedPanel banner = rounded(GreenTheme.TINT, GreenTheme.BORDER, 9);
        banner.setLayout(new BorderLayout());
        banner.setBorder(new EmptyBorder(11, 15, 11, 15));
        banner.add(label("ⓘ   Đang xem dữ liệu mẫu. Doanh thu, đơn hàng và lịch làm việc sẽ kết nối CSDL sau.",
                11, Font.PLAIN, GreenTheme.ACCENT));
        banner.setMaximumSize(new Dimension(Integer.MAX_VALUE, 41));
        content.add(banner);
        content.add(Box.createVerticalStrut(14));

        JPanel kpis = new JPanel(new GridLayout(1, 4, 12, 0));
        kpis.setOpaque(false);
        kpis.setMaximumSize(new Dimension(Integer.MAX_VALUE, 113));
        kpis.add(stat("Tổng doanh thu", "14.110.000 đ", "Tiền bán đã thanh toán", "wallet", ACCENT));
        kpis.add(stat("Tiền hoàn / trả", "0 đ", "Hoàn tiền bán hàng", "return", RED));
        kpis.add(stat("Doanh thu thuần", "14.110.000 đ", "Doanh thu sau hoàn trả", "chart", GREEN));
        kpis.add(stat("Hóa đơn đã bán", "2", "Đã thanh toán", "clipboard", GOLD));
        content.add(kpis);
        content.add(Box.createVerticalStrut(14));

        JPanel firstRow = dashboardRow(chartCard(), pendingCard(), 0.63);
        firstRow.setPreferredSize(new Dimension(850, 264));
        firstRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 264));
        content.add(firstRow);
        content.add(Box.createVerticalStrut(14));

        JPanel secondRow = dashboardRow(recentCard(), scheduleCard(), 0.63);
        secondRow.setPreferredSize(new Dimension(850, 230));
        secondRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 230));
        content.add(secondRow);
        content.add(Box.createVerticalStrut(14));

        JPanel end = new JPanel(new BorderLayout());
        end.setOpaque(false);
        end.add(label("Green Home · Giao diện mô phỏng", 10, Font.PLAIN, MUTED), BorderLayout.WEST);
        end.add(label("Nhấn F1 để xem hướng dẫn & phím tắt", 10, Font.PLAIN, MUTED), BorderLayout.EAST);
        end.setMaximumSize(new Dimension(Integer.MAX_VALUE, 20));
        content.add(end);

        JPanel centered = new JPanel(new GridBagLayout());
        centered.setBackground(BG);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.NORTH;
        centered.add(content, gbc);

        JScrollPane scroll = new JScrollPane(centered);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(BG);
        scroll.getVerticalScrollBar().setUnitIncrement(18);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        wrapper.add(scroll, BorderLayout.CENTER);
        return wrapper;
    }

    private JPanel dashboardRow(JPanel left, JPanel right, double leftRatio) {
        JPanel row = new JPanel(new GridBagLayout());
        row.setOpaque(false);
        left.setPreferredSize(new Dimension(0, 210));
        right.setPreferredSize(new Dimension(0, 210));
        left.setMinimumSize(new Dimension(0, 0));
        right.setMinimumSize(new Dimension(0, 0));
        GridBagConstraints a = new GridBagConstraints();
        a.gridx = 0;
        a.gridy = 0;
        a.weightx = leftRatio;
        a.weighty = 1;
        a.fill = GridBagConstraints.BOTH;
        a.insets = new Insets(0, 0, 0, 7);
        row.add(left, a);
        GridBagConstraints b = new GridBagConstraints();
        b.gridx = 1;
        b.gridy = 0;
        b.weightx = 1 - leftRatio;
        b.weighty = 1;
        b.fill = GridBagConstraints.BOTH;
        b.insets = new Insets(0, 7, 0, 0);
        row.add(right, b);
        return row;
    }

    private JPanel stat(String title, String value, String caption, String icon, Color accent) {
        RoundedPanel card = rounded(CARD, BORDER, 12);
        card.setLayout(new BorderLayout(8, 0));
        card.setBorder(new EmptyBorder(15, 15, 13, 13));
        JPanel text = vertical();
        text.add(label(title, 11, Font.PLAIN, MUTED));
        text.add(Box.createVerticalStrut(9));
        text.add(label(value, 20, Font.BOLD, GreenTheme.ACCENT));
        text.add(Box.createVerticalStrut(7));
        text.add(label(caption, 10, Font.PLAIN, MUTED));
        card.add(text, BorderLayout.CENTER);
        JLabel badge = new JLabel(new UiIcon(icon, accent, 15));
        badge.setVerticalAlignment(SwingConstants.TOP);
        card.add(badge, BorderLayout.EAST);
        return card;
    }

    private JPanel chartCard() {
        RoundedPanel panel = section("Bán hàng & hoàn trả", "Tổng giá trị theo ngày", "Chi tiết", laQuanLy ? () -> showPage("Thống kê") : null);
        panel.add(new SalesChart(), BorderLayout.CENTER);
        return panel;
    }

    private JPanel pendingCard() {
        RoundedPanel card = section("Cần xử lý", "Công việc đang chờ", "Xem tất cả", () -> showPage("Đổi / trả"));
        JPanel list = vertical();
        list.setBorder(new EmptyBorder(8, 0, 0, 0));
        list.add(pendingItem("Chờ phê duyệt đổi / trả", "1 phiếu đang chờ quản lý", "clipboard", GOLD, "1"));
        list.add(new JSeparator());
        list.add(pendingItem("Đơn đang xử lý", "Theo dõi tiến độ tại quầy", "cart", RED, "0"));
        list.add(new JSeparator());
        list.add(Box.createVerticalStrut(12));
        list.add(label("Dữ liệu minh họa từ thiết kế Green Home", 10, Font.PLAIN, MUTED));
        card.add(list, BorderLayout.CENTER);
        return card;
    }

    private JPanel pendingItem(String title, String subtitle, String icon, Color color, String count) {
        JPanel p = new JPanel(new BorderLayout(9, 0));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(9, 3, 10, 3));
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 58));
        p.add(new JLabel(new UiIcon(icon, color, 17)), BorderLayout.WEST);
        JPanel center = vertical();
        center.add(label(title, 12, Font.BOLD, TEXT));
        center.add(Box.createVerticalStrut(4));
        center.add(label(subtitle, 10, Font.PLAIN, MUTED));
        p.add(center, BorderLayout.CENTER);
        p.add(label(count, 13, Font.BOLD, GreenTheme.ACCENT), BorderLayout.EAST);
        return p;
    }

    private JPanel recentCard() {
        RoundedPanel card = section(
                "Giao dịch gần đây",
                "Hóa đơn mẫu đã thanh toán",
                "Tra cứu",
                () -> moHoaDon(null)
        );
        String[] columns = {
            "Hóa đơn",
            "Khách hàng",
            "Thực thanh toán",
            "Thời gian"
        };

        Object[][] rows = {
            {"HD000001", "Trần Thị Mai", "11.610.000 đ", "15/10/2026"},
            {"HD000002", "Lê Hoàng Nam", "2.500.000 đ", "16/10/2026"}
        };

        DefaultTableModel model = new DefaultTableModel(rows, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable table = new JTable(model);
        table.setRowHeight(37);
        table.setShowGrid(false);
        table.setBackground(CARD);
        table.setForeground(TEXT);
        table.setSelectionBackground(GreenTheme.TINT);
        table.setSelectionForeground(TEXT);
        table.setFont(new Font("SansSerif", Font.PLAIN, 11));
        table.setFillsViewportHeight(true);
        table.getTableHeader().setReorderingAllowed(false);
        table.getTableHeader().setPreferredSize(new Dimension(0, 32));

        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(
                    JTable t, Object value,
                    boolean selected, boolean focus,
                    int row, int column) {
                super.getTableCellRendererComponent(t, value, selected, focus, row, column);
                setBorder(new EmptyBorder(5, 12, 5, 6));
                setBackground(GreenTheme.SOFT);
                setForeground(MUTED);
                setFont(new Font("SansSerif", Font.BOLD, 10));
                return this;
            }
        };
        table.getTableHeader().setDefaultRenderer(headerRenderer);

        DefaultTableCellRenderer cellRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(
                    JTable t, Object value,
                    boolean selected, boolean focus,
                    int row, int column) {
                super.getTableCellRendererComponent(t, value, selected, focus, row, column);
                setBorder(new EmptyBorder(0, 12, 0, 6));
                return this;
            }
        };
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(cellRenderer);
        }

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(CARD);

        JPanel tableArea = new JPanel(new BorderLayout());
        tableArea.setOpaque(false);
        tableArea.setBorder(new EmptyBorder(0, 8, 0, 8));
        tableArea.add(scroll, BorderLayout.CENTER);
        card.add(tableArea, BorderLayout.CENTER);
        return card;
    }

    private JPanel scheduleCard() {
        RoundedPanel card = section("Lịch làm việc sắp tới", "Các ca đã phân công (mẫu)",
                "Xem lịch", () -> showPage("Lịch làm việc"));
        JPanel list = vertical();
        list.setBorder(new EmptyBorder(3, 0, 0, 0));
        list.add(scheduleRow(LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern("dd/MM")), "Nguyễn Văn A", "Ca sáng · 08:00–14:00", ACCENT));
        list.add(new JSeparator());
        list.add(scheduleRow(LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern("dd/MM")), "Trần Thị Linh", "Ca chiều · 14:00–18:00", GOLD));
        list.add(new JSeparator());
        list.add(scheduleRow(LocalDate.now().plusDays(2).format(DateTimeFormatter.ofPattern("dd/MM")), "Lê Hoàng Minh", "Ca tối · 18:00–22:00", GreenTheme.PURPLE));
        card.add(list, BorderLayout.CENTER);
        return card;
    }

    private JPanel scheduleRow(String day, String employee, String shift, Color accent) {
        JPanel row = new JPanel(new BorderLayout(10, 0));
        row.setOpaque(false);
        row.setBorder(new EmptyBorder(8, 0, 8, 0));
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 62));
        JLabel date = label("<html><center>" + day.replace("/", "<br>") + "</center></html>", 11, Font.BOLD, TEXT);
        date.setHorizontalAlignment(SwingConstants.CENTER);
        date.setPreferredSize(new Dimension(37, 43));
        date.setOpaque(true);
        date.setBackground(GreenTheme.SOFT);
        row.add(date, BorderLayout.WEST);
        JPanel info = vertical();
        info.add(label(employee, 11, Font.BOLD, TEXT));
        info.add(Box.createVerticalStrut(4));
        info.add(label(shift, 10, Font.PLAIN, MUTED));
        row.add(info, BorderLayout.CENTER);
        JLabel tag = label("●", 13, Font.BOLD, accent);
        row.add(tag, BorderLayout.EAST);
        return row;
    }

    private RoundedPanel section(String title, String sub, String buttonText, Runnable action) {
        RoundedPanel card = rounded(CARD, BORDER, 12);
        card.setLayout(new BorderLayout(0, 10));
        card.setBorder(new EmptyBorder(14, 14, 12, 14));
        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        JPanel labels = vertical();
        labels.add(label(title, 13, Font.BOLD, TEXT));
        labels.add(Box.createVerticalStrut(4));
        labels.add(label(sub, 10, Font.PLAIN, MUTED));
        top.add(labels, BorderLayout.WEST);
        if (action != null) top.add(smallButton(buttonText, "arrow", action), BorderLayout.EAST);
        card.add(top, BorderLayout.NORTH);
        return card;
    }

    // ==================== CAC THANH PHAN DUNG CHUNG ====================

    private static JPanel vertical() {
        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        return panel;
    }

    private static JLabel label(String text, int size, int style, Color color) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("SansSerif", style, size));
        label.setForeground(color);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        return label;
    }

    private static RoundedPanel rounded(Color bg, Color border, int radius) {
        return new RoundedPanel(bg, border, radius);
    }

    private JButton smallButton(String title, String icon, Runnable action) {
        JButton button = new JButton(title, new UiIcon(icon, MUTED, 12));
        button.setBackground(GreenTheme.SOFT);
        button.setForeground(TEXT);
        button.setFont(new Font("SansSerif", Font.PLAIN, 10));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER), new EmptyBorder(6, 8, 6, 8)));
        button.addActionListener(e -> action.run());
        return button;
    }

    private JButton primaryButton(String title, String icon, Runnable action) {
        JButton button = new JButton(title, new UiIcon(icon, Color.WHITE, 13));
        button.setBackground(ACCENT);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("SansSerif", Font.BOLD, 11));
        button.setFocusPainted(false);
        button.setBorder(new EmptyBorder(9, 11, 9, 11));
        button.addActionListener(e -> action.run());
        return button;
    }

    private static String initials(String name) {
        String trimmed = name.trim();
        if (trimmed.isEmpty()) return "?";
        String[] parts = trimmed.split("\\s+");
        return parts[parts.length - 1].substring(0, 1).toUpperCase();
    }

    private JPanel placeholder(String name) {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(BG);
        JPanel inner = vertical();
        inner.add(label(name, 24, Font.BOLD, TEXT));
        inner.add(Box.createVerticalStrut(12));
        inner.add(label("Trang giao diện sẽ được code ở bước tiếp theo.", 13, Font.PLAIN, MUTED));
        panel.add(inner);
        return panel;
    }

    private JPanel createPage(String name) {
        return switch (name) {
            case "Bán hàng" -> new BanHangPanel(this::themKhachTuQuay, this::moHoaDon);
            case "Hóa đơn" -> new HoaDonPanel();
            case "Khách hàng" -> new KhachHangPanel(this::moHoaDon);
            case "Sản phẩm" -> new SanPhamPanel(laQuanLy);
            case "Khuyến mãi" -> new KhuyenMaiPanel(laQuanLy);
            case "Đổi / trả" -> new DoiTraPanel(laQuanLy);
            case "Lịch làm việc" -> new LichLamViecPanel(laQuanLy, tenNguoiDung);
            case "Thống kê" -> new ThongKePanel();
            case "Nhân viên & tài khoản" -> new NhanVienPanel();
            default -> placeholder(name);
        };
    }

    void themKhachTuQuay(String tuKhoa) {
        if (!showPage("Khách hàng")) return;
        BanHangPanel quay = (BanHangPanel) pages.get("Bán hàng");
        ((KhachHangPanel) pages.get("Khách hàng")).themTuQuay(tuKhoa, quay::chonKhachVuaTao);
        showPage("Bán hàng");
    }

    void moHoaDon(String maHD) {
        if (showPage("Hóa đơn") && maHD != null) {
            HoaDonPanel.moChiTiet(pages.get("Hóa đơn"), maHD);
        }
    }

    private boolean showPage(String name) {
        boolean vuaChuyenTab = !name.equals(lblPageTitle.getText());
        if (!menuButtons.containsKey(name)) {
            info("Trang " + name + " chưa có trong menu của vai trò này");
            return false;
        }
        if (!pagesDaMo.contains(name)) {
            try {
                JPanel panel = createPage(name);
                cardPanel.remove(pages.get(name));
                cardPanel.add(panel, name);
                pages.put(name, panel);
                pagesDaMo.add(name);
            } catch (RuntimeException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(),
                        "Không mở được trang " + name, JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
        try {
            JPanel page = pages.get(name);
            if (page instanceof NhanVienPanel nv) nv.lamMoiTuCSDL();
            if (page instanceof LichLamViecPanel lich) lich.lamMoiTuCSDL();
            if (page instanceof KhachHangPanel kh) kh.lamMoiTuCSDL();
            if (page instanceof DoiTraPanel dt) dt.lamMoiTuCSDL();
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Không tải được dữ liệu", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        cardLayout.show(cardPanel, name);
        lblPageTitle.setText(name);
        if (vuaChuyenTab && pages.get(name) instanceof SanPhamPanel sp) {
            sp.canhBaoTonKhiMoTrang();
        }
        if (pages.get(name) instanceof HoaDonPanel hd) hd.lamMoiDuLieu();
        for (Component panel : cardPanel.getComponents()) {
            if (panel.isVisible() && panel instanceof BanHangPanel) ((BanHangPanel) panel).lamMoiDuLieu();
            if (panel.isVisible() && panel instanceof ThongKePanel) ((ThongKePanel) panel).lamMoiDuLieu();
        }
        for (Map.Entry<String, JButton> entry : menuButtons.entrySet()) {
            boolean selected = entry.getKey().equals(name);
            JButton button = entry.getValue();
            button.setBackground(selected ? GreenTheme.TINT : SIDE);
            button.setForeground(selected ? GreenTheme.ACCENT : MUTED);
            button.setFont(new Font("SansSerif", selected ? Font.BOLD : Font.PLAIN, 12));
            String icon = menuIcon(entry.getKey());
            button.setIcon(new UiIcon(icon, selected ? ACCENT : MUTED, 17));
        }
        return true;
    }

    private String menuIcon(String name) {
        switch (name) {
            case "Tổng quan": return "grid";
            case "Bán hàng": return "cart";
            case "Hóa đơn": return "history";
            case "Khách hàng": return "users";
            case "Sản phẩm": return "box";
            case "Khuyến mãi": return "tag";
            case "Đổi / trả": return "return";
            case "Lịch làm việc": return "calendar";
            case "Thống kê": return "chart";
            default: return "users";
        }
    }

    private void info(String feature) {
        JOptionPane.showMessageDialog(this,
                feature + " sẽ được triển khai trong giai đoạn tiếp theo.",
                "Green Home - Giao diện mẫu", JOptionPane.INFORMATION_MESSAGE);
    }

    private void logout() {
        int result = JOptionPane.showConfirmDialog(this, "Bạn có muốn đăng xuất không?",
                "Xác nhận đăng xuất", JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {
            QuanLyHoanTac.xoaLichSu();
            util.PhienDangNhap.ketThuc();
            new LoginFrame().setVisible(true);
            dispose();
        }
    }

    // ==================== VE THU CONG ====================

    private static class RoundedPanel extends JPanel {
        private final Color background;
        private final Color outline;
        private final int radius;
        RoundedPanel(Color background, Color outline, int radius) {
            this.background = background;
            this.outline = outline;
            this.radius = radius;
            setOpaque(false);
        }
        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(background);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);
            g2.setColor(outline);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);
            g2.dispose();
        }
    }

    private static class Avatar extends JComponent {
        private final String value;
        private final Color fill;
        private final int size;
        private final int arc;
        Avatar(String value, Color fill, int size, int arc) {
            this.value = value;
            this.fill = fill;
            this.size = size;
            this.arc = arc;
            setPreferredSize(new Dimension(size, size));
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(fill);
            g2.fillRoundRect(0, 0, size, size, arc, arc);
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("SansSerif", Font.BOLD, 14));
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(value, (size - fm.stringWidth(value)) / 2,
                    (size + fm.getAscent() - fm.getDescent()) / 2);
            g2.dispose();
        }
    }

    private static class UiIcon implements Icon {
        private final String kind;
        private final Color color;
        private final int size;
        UiIcon(String kind, Color color, int size) {
            this.kind = kind;
            this.color = color;
            this.size = size;
        }
        @Override public int getIconWidth() { return size; }
        @Override public int getIconHeight() { return size; }
        @Override public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D p = (Graphics2D) g.create();
            p.translate(x, y);
            p.scale(size / 20.0, size / 20.0);
            p.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            p.setStroke(new BasicStroke(1.65f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            p.setColor(color);
            switch (kind) {
                case "grid":
                    for (int a = 2; a <= 11; a += 9) for (int b = 2; b <= 11; b += 9)
                        p.drawRoundRect(a, b, 7, 7, 2, 2);
                    break;
                case "users":
                    p.drawOval(7, 2, 6, 6); p.drawArc(3, 10, 14, 10, 0, 180);
                    p.drawArc(0, 2, 5, 9, 90, 180); p.drawArc(15, 2, 5, 9, 270, 180);
                    break;
                case "cart":
                    p.drawLine(1, 2, 4, 2); p.drawLine(4, 2, 6, 13);
                    p.drawLine(6, 13, 17, 13); p.drawLine(5, 5, 19, 5);
                    p.drawLine(19, 5, 17, 11); p.drawOval(7, 16, 1, 1); p.drawOval(15, 16, 1, 1);
                    break;
                case "box":
                    p.draw(new Rectangle2D.Double(3, 6, 14, 11));
                    p.drawLine(3, 6, 10, 2); p.drawLine(10, 2, 17, 6);
                    p.drawLine(3, 6, 10, 10); p.drawLine(17, 6, 10, 10); p.drawLine(10, 10, 10, 17);
                    break;
                case "tag":
                    Path2D tag = new Path2D.Double(); tag.moveTo(3, 3); tag.lineTo(11, 3);
                    tag.lineTo(18, 10); tag.lineTo(10, 18); tag.lineTo(3, 11); tag.closePath();
                    p.draw(tag); p.drawOval(5, 5, 2, 2);
                    break;
                case "return":
                    p.drawArc(4, 3, 12, 11, 30, 240);
                    p.drawLine(2, 9, 4, 15); p.drawLine(4, 15, 9, 12);
                    break;
                case "calendar":
                    p.drawRoundRect(2, 4, 16, 14, 2, 2); p.drawLine(2, 9, 18, 9);
                    p.drawLine(6, 2, 6, 6); p.drawLine(14, 2, 14, 6); p.drawLine(6, 13, 9, 13);
                    break;
                case "chart":
                    p.drawLine(2, 18, 18, 18); p.drawLine(2, 18, 2, 3);
                    p.drawRect(5, 11, 2, 7); p.drawRect(10, 7, 2, 11); p.drawRect(15, 3, 2, 15);
                    break;
                case "wallet":
                    p.drawRoundRect(2, 5, 16, 12, 2, 2); p.drawLine(2, 8, 18, 8);
                    p.drawRoundRect(12, 10, 6, 4, 1, 1);
                    break;
                case "clipboard":
                    p.drawRoundRect(4, 4, 12, 14, 2, 2); p.drawRoundRect(7, 2, 6, 4, 1, 1);
                    p.drawLine(7, 10, 13, 10); p.drawLine(7, 14, 13, 14);
                    break;
                case "history":
                    p.drawArc(3, 3, 14, 14, 0, 285);
                    p.drawLine(3, 3, 3, 8); p.drawLine(3, 8, 8, 7);
                    p.drawLine(10, 6, 10, 10); p.drawLine(10, 10, 13, 12);
                    break;
                case "logout":
                    p.drawLine(11, 3, 3, 3); p.drawLine(3, 3, 3, 17);
                    p.drawLine(3, 17, 11, 17); p.drawLine(9, 10, 19, 10);
                    p.drawLine(15, 6, 19, 10); p.drawLine(19, 10, 15, 14);
                    break;
                case "help":
                    p.drawOval(2, 2, 16, 16); p.drawArc(7, 5, 6, 7, 0, 180);
                    p.drawLine(10, 11, 10, 13); p.fillOval(9, 15, 2, 2);
                    break;
                default:
                    p.drawLine(4, 10, 16, 10); p.drawLine(12, 6, 16, 10); p.drawLine(16, 10, 12, 14);
            }
            p.dispose();
        }
    }

    private static class SalesChart extends JPanel {
        SalesChart() { setOpaque(false); }
        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D p = (Graphics2D) g.create();
            p.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int left = 44, top = 16, right = getWidth() - 16, bottom = getHeight() - 32;
            if (right <= left || bottom <= top) { p.dispose(); return; }
            p.setFont(new Font("SansSerif", Font.PLAIN, 10));
            String[] ticks = {"0", "3 tr", "6 tr", "9 tr", "12 tr"};
            for (int i = 0; i < ticks.length; i++) {
                int y = bottom - (bottom - top) * i / 4;
                p.setColor(GreenTheme.BORDER);
                p.drawLine(left, y, right, y);
                p.setColor(MUTED);
                p.drawString(ticks[i], 5, y + 4);
            }
            String[] days = {"11/10", "12/10", "13/10", "14/10", "15/10", "16/10", "17/10"};
            double[] values = {0, 0, 0, 0, 11.61, 2.5, 0};
            int width = right - left;
            for (int i = 0; i < days.length; i++) {
                int x = left + (int) ((i + .5) * width / days.length);
                int height = (int) ((bottom - top) * values[i] / 12.0);
                if (height > 0) {
                    p.setColor(ACCENT);
                    p.fillRoundRect(x - 10, bottom - height, 20, height, 4, 4);
                }
                p.setColor(MUTED);
                int textWidth = p.getFontMetrics().stringWidth(days[i]);
                p.drawString(days[i], x - textWidth / 2, bottom + 17);
            }
            p.dispose();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}