package ui;

import java.awt.Color;
import javax.swing.UIManager;

/** Bảng màu chung cho màn hình nghiệp vụ và các hộp thoại Swing. */
final class GreenTheme {
    static final Color CANVAS = new Color(0xF3F8F4);
    static final Color SURFACE = new Color(0xFFFFFF);
    static final Color SOFT = new Color(0xEDF5EF);
    static final Color TINT = new Color(0xDDEFE3);
    static final Color BORDER = new Color(0xC5D8CB);
    static final Color TEXT = new Color(0x173B2B);
    static final Color MUTED = new Color(0x486556);
    static final Color ACCENT = new Color(0x166342);
    static final Color GREEN = new Color(0x217347);
    static final Color GOLD = new Color(0x835008);
    static final Color RED = new Color(0xA0313C);
    static final Color PURPLE = new Color(0x704182);
    static final Color BLUSH = new Color(0xF7E9EF);
    static final Color CREAM = new Color(0xFAF0D8);
    static final Color ILLUSTRATION = new Color(0x67977C);

    private GreenTheme() {}

    static void install() {
        UIManager.put("Panel.background", SURFACE);
        UIManager.put("OptionPane.background", SURFACE);
        UIManager.put("OptionPane.messageForeground", TEXT);
        UIManager.put("Label.foreground", TEXT);
        UIManager.put("Button.background", SOFT);
        UIManager.put("Button.foreground", TEXT);
        UIManager.put("Button.disabledText", MUTED);
        UIManager.put("Separator.foreground", BORDER);
        UIManager.put("Separator.background", SURFACE);
        UIManager.put("CheckBox.background", SURFACE);
        UIManager.put("CheckBox.foreground", TEXT);
        UIManager.put("ComboBox.selectionBackground", TINT);
        UIManager.put("ComboBox.selectionForeground", TEXT);
        UIManager.put("List.selectionBackground", TINT);
        UIManager.put("List.selectionForeground", TEXT);
        UIManager.put("TextField.selectionBackground", TINT);
        UIManager.put("TextField.selectionForeground", TEXT);
        UIManager.put("ProgressBar.foreground", ACCENT);
    }
}
