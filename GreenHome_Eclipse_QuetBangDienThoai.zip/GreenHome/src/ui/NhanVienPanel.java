package ui;

import bus.NhanVienBUS;
import entity.NhanVien;
import entity.TaiKhoan;
import entity.VaiTro;
import util.HoTroPhimTat;
import util.PhienDangNhap;
import util.QuanLyHoanTac;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/** UI-11: Quản lý nhân viên, tài khoản qua BUS/DAO/SQL Server. */
public class NhanVienPanel extends JPanel implements HoTroPhimTat {

    private static final Color BG = GreenTheme.CANVAS;
    private static final Color CARD = GreenTheme.SURFACE;
    private static final Color BORDER = GreenTheme.BORDER;
    private static final Color TEXT = GreenTheme.TEXT;
    private static final Color MUTED = GreenTheme.MUTED;
    private static final Color ACCENT = GreenTheme.ACCENT;
    private static final Color GREEN = GreenTheme.GREEN;
    private static final Color GOLD = GreenTheme.GOLD;
    private static final DateTimeFormatter DATE = DateTimeFormatter
            .ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT);

    private final List<DongNhanVien> nhanViens = new ArrayList<>();
    private final List<DongNhanVien> dangHienThi = new ArrayList<>();
    private final NhanVienBUS bus;

    private final JTextField txtTim = new JTextField();
    private final JComboBox<String> cboVaiTro = new JComboBox<>(new String[] {
            "Tất cả vai trò", "Nhân viên bán hàng", "Quản lý"
    });
    private final JComboBox<String> cboTrangThai = new JComboBox<>(new String[] {
            "Mọi trạng thái", "Đang làm", "Đã nghỉ", "Tài khoản khóa"
    });
    private final JLabel lblDangLam = text("0", 23, Font.BOLD, ACCENT);
    private final JLabel lblTaiKhoan = text("0", 23, Font.BOLD, GREEN);
    private final JLabel lblNgung = text("0", 23, Font.BOLD, GOLD);
    private final JLabel lblSoDong = text("0 nhân viên", 11, Font.PLAIN, MUTED);

    private final DefaultTableModel model = new DefaultTableModel(new String[] {
            "Nhân viên", "Liên hệ", "Vai trò", "Tài khoản", "Trạng thái", "Sửa", "Khóa / Mở"
    }, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable table = new JTable(model);

    public NhanVienPanel() {
        bus = new NhanVienBUS(PhienDangNhap.hienTai().getMaNV());
        if (!PhienDangNhap.laQuanLy()) throw new SecurityException("Chỉ Quản lý được mở trang nhân viên.");
        setLayout(new BorderLayout());
        setBackground(BG);
        taoGiaoDien();
        lamMoiTuCSDL();
    }

    @Override
    public void phimThemMoi() {
        moForm(null);
    }

    @Override
    public void phimTimKiem() {
        txtTim.requestFocusInWindow();
        txtTim.selectAll();
    }

    @Override
    public void phimLamMoi() {
        lamMoiTuCSDL();
    }

    /** Dữ liệu nạp lại từ SQL, không còn lưu mẫu trong RAM. */
    public void lamMoiTuCSDL() {
        nhanViens.clear();
        for (NhanVien nv : bus.layTatCa()) {
            TaiKhoan tk = nv.getTaiKhoan();
            nhanViens.add(new DongNhanVien(nv.getMaNV(), nv.getHoTen(), nv.getSdtNV(),
                    nv.getSoCCCD(), nv.getNgaySinh(), nv.getNgayVaoLam(),
                    tk != null && tk.getVaiTro() == VaiTro.QUAN_LY ? "Quản lý" : "Nhân viên bán hàng",
                    tk == null ? "" : tk.getTenDangNhap(), nv.getDiaChi() == null ? "" : nv.getDiaChi(),
                    nv.isDangLamViec(), tk != null && tk.isDangHoatDong()));
        }
        taiDanhSach();
    }

    private void taoGiaoDien() {
        JPanel page = new JPanel(new BorderLayout(0, 15));
        page.setBorder(new EmptyBorder(22, 26, 22, 26));
        page.setBackground(BG);
        add(page, BorderLayout.CENTER);

        JPanel top = new JPanel(new BorderLayout(0, 15));
        top.setOpaque(false);
        JPanel heading = new JPanel(new BorderLayout());
        heading.setOpaque(false);
        JPanel titles = vertical();
        titles.add(text("Nhân viên & tài khoản", 21, Font.BOLD, TEXT));
        titles.add(Box.createVerticalStrut(5));
        titles.add(text("Quản lý hồ sơ, phân quyền và trạng thái truy cập của nhân viên.", 11, Font.PLAIN, MUTED));
        heading.add(titles, BorderLayout.WEST);

        // Đã bỏ nút Nhập Excel, chỉ giữ nút + Thêm nhân viên
        JButton btnThem = button("+  Thêm nhân viên", true);
        btnThem.setToolTipText("Thêm nhân viên mới (Ctrl + N)");
        btnThem.addActionListener(e -> moForm(null));
        JPanel tools = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        tools.setOpaque(false);
        tools.add(btnThem);
        heading.add(tools, BorderLayout.EAST);
        top.add(heading, BorderLayout.NORTH);

        JPanel stats = new JPanel(new GridLayout(1, 3, 12, 0));
        stats.setOpaque(false);
        stats.setPreferredSize(new Dimension(0, 104));
        stats.add(stat("Đang làm việc", lblDangLam, "Nhân viên còn làm tại cửa hàng", ACCENT));
        stats.add(stat("Tài khoản hoạt động", lblTaiKhoan, "Có quyền truy cập theo vai trò", GREEN));
        stats.add(stat("Đã nghỉ / khóa", lblNgung, "Nhân viên nghỉ hoặc tài khoản bị khóa", GOLD));
        top.add(stats, BorderLayout.CENTER);
        page.add(top, BorderLayout.NORTH);

        JPanel listCard = new JPanel(new BorderLayout());
        listCard.setBackground(CARD);
        listCard.setBorder(new LineBorder(BORDER));
        JPanel filters = new JPanel(new FlowLayout(FlowLayout.LEFT, 9, 10));
        filters.setBackground(CARD);
        styleInput(txtTim);
        txtTim.setPreferredSize(new Dimension(280, 36));
        txtTim.setToolTipText("Tìm họ tên, mã, SĐT hoặc tài khoản (Ctrl + F)");
        styleCombo(cboVaiTro);
        styleCombo(cboTrangThai);
        filters.add(txtTim);
        filters.add(cboVaiTro);
        filters.add(cboTrangThai);
        listCard.add(filters, BorderLayout.NORTH);

        table.setRowHeight(58);
        table.setShowGrid(false);
        table.setFillsViewportHeight(true);
        table.setBackground(CARD);
        table.setForeground(TEXT);
        table.setSelectionBackground(GreenTheme.TINT);
        table.setSelectionForeground(TEXT);
        table.setFont(new Font("SansSerif", Font.PLAIN, 11));
        table.getTableHeader().setReorderingAllowed(false);
        table.getTableHeader().setPreferredSize(new Dimension(0, 35));
        table.getTableHeader().setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean selected, boolean focus, int row, int col) {
                super.getTableCellRendererComponent(t, v, selected, focus, row, col);
                setBackground(GreenTheme.SOFT);
                setForeground(MUTED);
                setFont(new Font("SansSerif", Font.BOLD, 10));
                setBorder(new EmptyBorder(0, 12, 0, 5));
                return this;
            }
        });
        DefaultTableCellRenderer cell = new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean selected, boolean focus, int row, int col) {
                super.getTableCellRendererComponent(t, v, selected, focus, row, col);
                setBorder(new EmptyBorder(0, 12, 0, 5));
                setHorizontalAlignment(col >= 5 ? SwingConstants.CENTER : SwingConstants.LEFT);
                if (col == 5 || col == 6) setForeground(GreenTheme.ACCENT);
                else if (col == 4) setForeground("Đang làm".equals(v) ? GREEN : MUTED);
                else setForeground(TEXT);
                return this;
            }
        };
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(cell);
        }
        table.getColumnModel().getColumn(0).setPreferredWidth(220);
        table.getColumnModel().getColumn(1).setPreferredWidth(170);
        table.getColumnModel().getColumn(2).setPreferredWidth(145);
        table.getColumnModel().getColumn(3).setPreferredWidth(125);
        table.getColumnModel().getColumn(4).setPreferredWidth(105);
        table.getColumnModel().getColumn(5).setPreferredWidth(60);
        table.getColumnModel().getColumn(6).setPreferredWidth(95);

        table.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                int row = table.rowAtPoint(e.getPoint());
                int col = table.columnAtPoint(e.getPoint());
                if (row < 0 || (col != 5 && col != 6)) return;
                DongNhanVien nv = dangHienThi.get(table.convertRowIndexToModel(row));
                if (col == 5) moForm(nv);
                else doiKhoaTaiKhoan(nv);
            }
        });
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(CARD);
        listCard.add(scroll, BorderLayout.CENTER);
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 6));
        bottom.setBackground(CARD);
        bottom.add(lblSoDong);
        listCard.add(bottom, BorderLayout.SOUTH);
        page.add(listCard, BorderLayout.CENTER);

        txtTim.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { taiDanhSach(); }
            public void removeUpdate(DocumentEvent e) { taiDanhSach(); }
            public void changedUpdate(DocumentEvent e) { taiDanhSach(); }
        });
        cboVaiTro.addActionListener(e -> taiDanhSach());
        cboTrangThai.addActionListener(e -> taiDanhSach());
    }

    private void taiDanhSach() {
        String q = txtTim.getText().trim().toLowerCase(Locale.ROOT);
        String vaiTro = String.valueOf(cboVaiTro.getSelectedItem());
        String trangThai = String.valueOf(cboTrangThai.getSelectedItem());
        dangHienThi.clear();
        model.setRowCount(0);
        int lamViec = 0, taiKhoan = 0, ngung = 0;
        for (DongNhanVien nv : nhanViens) {
            if (nv.dangLamViec) lamViec++;
            if (nv.dangLamViec && nv.choPhepTruyCap) taiKhoan++;
            if (!nv.dangLamViec || !nv.choPhepTruyCap) ngung++;

            String searchable = (nv.ma + " " + nv.hoTen + " " + nv.sdt + " " + nv.tenDangNhap)
                    .toLowerCase(Locale.ROOT);
            boolean matchVaiTro = vaiTro.startsWith("Tất cả") || vaiTro.equals(nv.vaiTro);
            boolean matchTrangThai = "Mọi trạng thái".equals(trangThai)
                    || ("Đang làm".equals(trangThai) && nv.dangLamViec)
                    || ("Đã nghỉ".equals(trangThai) && !nv.dangLamViec)
                    || ("Tài khoản khóa".equals(trangThai) && !nv.choPhepTruyCap);
            if (!searchable.contains(q) || !matchVaiTro || !matchTrangThai) continue;
            dangHienThi.add(nv);
            model.addRow(new Object[] {
                    "<html><b>" + escape(nv.hoTen) + "</b><br><font color='#486556'>" + nv.ma + "</font></html>",
                    "<html>" + nv.sdt + "<br><font color='#486556'>CCCD: ****" + nv.cccd.substring(8) + "</font></html>",
                    nv.vaiTro,
                    "<html>" + escape(nv.tenDangNhap) + "<br><font color='#486556'>"
                            + (nv.choPhepTruyCap ? "Đang mở" : "Đã khóa") + "</font></html>",
                    nv.dangLamViec ? "Đang làm" : "Đã nghỉ",
                    "Sửa",
                    nv.dangLamViec ? (nv.choPhepTruyCap ? "Khóa" : "Mở khóa") : "—"
            });
        }
        lblDangLam.setText(String.valueOf(lamViec));
        lblTaiKhoan.setText(String.valueOf(taiKhoan));
        lblNgung.setText(String.valueOf(ngung));
        lblSoDong.setText(dangHienThi.size() + " nhân viên");
    }

    private void doiKhoaTaiKhoan(DongNhanVien nv) {
        if (!nv.dangLamViec) {
            JOptionPane.showMessageDialog(this, "Nhân viên đã nghỉ. Cập nhật trạng thái làm việc trước.");
            return;
        }
        boolean trangThaiCu = nv.choPhepTruyCap;
        String action = trangThaiCu ? "Khóa" : "Mở khóa";
        int confirm = JOptionPane.showConfirmDialog(this,
                action + " tài khoản " + nv.tenDangNhap + "?\nHồ sơ và lịch sử giao dịch vẫn được giữ nguyên.",
                "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;
        try {
            if (!bus.khoaMoTaiKhoan(nv.ma, !trangThaiCu))
                throw new IllegalArgumentException("Không tìm thấy tài khoản.");

            QuanLyHoanTac.ghiNhan(
                (trangThaiCu ? "Mở lại" : "Khóa lại") + " tài khoản " + nv.tenDangNhap,
                () -> bus.khoaMoTaiKhoan(nv.ma, trangThaiCu),
                this::lamMoiTuCSDL
            );
            lamMoiTuCSDL();
        } catch (RuntimeException ex) {
            warning(this, ex.getMessage());
        }
    }

    private void moForm(DongNhanVien nvCu) {
        boolean sua = nvCu != null;
        Window owner = SwingUtilities.getWindowAncestor(this);
        JDialog dialog = new JDialog(owner, sua ? "Cập nhật nhân viên" : "Thêm nhân viên",
                Dialog.ModalityType.APPLICATION_MODAL);
        dialog.setSize(770, 690);
        dialog.setMinimumSize(new Dimension(640, 570));
        dialog.setLocationRelativeTo(owner);
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(CARD);
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(CARD);
        header.setBorder(new CompoundBorder(new MatteBorder(0, 0, 1, 0, BORDER),
                new EmptyBorder(20, 26, 20, 26)));
        JPanel title = vertical();
        title.add(text(sua ? "Cập nhật nhân viên" : "Thêm nhân viên", 22, Font.BOLD, TEXT));
        title.add(Box.createVerticalStrut(7));
        title.add(text(sua ? "Mã hồ sơ: " + nvCu.ma : "Tạo hồ sơ và tài khoản mẫu theo vai trò.",
                12, Font.PLAIN, MUTED));
        header.add(title, BorderLayout.WEST);
        JButton x = button("×", false);
        x.addActionListener(e -> dialog.dispose());
        header.add(x, BorderLayout.EAST);
        root.add(header, BorderLayout.NORTH);

        JTextField ten = input(sua ? nvCu.hoTen : "");
        JTextField sdt = input(sua ? nvCu.sdt : "");
        JTextField cccd = input(sua ? nvCu.cccd : "");
        JTextField ngaySinh = input(sua ? DATE.format(nvCu.ngaySinh) : "");
        JTextField ngayVao = input(sua ? DATE.format(nvCu.ngayVaoLam) : DATE.format(LocalDate.now()));
        JComboBox<String> vaiTro = new JComboBox<>(new String[] {"Nhân viên bán hàng", "Quản lý"});
        styleCombo(vaiTro);
        if (sua) vaiTro.setSelectedItem(nvCu.vaiTro);
        JTextField username = input(sua ? nvCu.tenDangNhap : "");
        JTextField diaChi = input(sua ? nvCu.diaChi : "");
        JCheckBox dangLam = checkbox("Nhân viên đang làm việc", !sua || nvCu.dangLamViec);
        JCheckBox truyCap = checkbox("Cho phép truy cập tài khoản", !sua || nvCu.choPhepTruyCap);
        truyCap.setEnabled(dangLam.isSelected());
        dangLam.addActionListener(e -> {
            if (!dangLam.isSelected()) truyCap.setSelected(false);
            truyCap.setEnabled(dangLam.isSelected());
        });

        JPanel fields = new JPanel(new GridLayout(4, 2, 17, 15));
        fields.setOpaque(false);
        fields.add(field("Họ tên *", ten));
        fields.add(field("Số điện thoại *", sdt));
        fields.add(field("CCCD *", cccd));
        fields.add(field("Ngày sinh * (dd/MM/yyyy)", ngaySinh));
        fields.add(field("Ngày vào làm * (dd/MM/yyyy)", ngayVao));
        fields.add(field("Vai trò *", vaiTro));
        fields.add(field("Tên đăng nhập mẫu *", username));
        fields.add(field("Địa chỉ", diaChi));
        JPanel checks = new JPanel(new GridLayout(1, 2, 15, 0));
        checks.setOpaque(false);
        checks.add(dangLam);
        checks.add(truyCap);
        JPanel notice = new JPanel(new BorderLayout());
        notice.setBackground(GreenTheme.SOFT);
        notice.setBorder(new EmptyBorder(13, 14, 13, 14));
        notice.add(text("ⓘ Tài khoản mới có mật khẩu ban đầu 123456 (chỉ dành cho demo).",
                11, Font.PLAIN, MUTED), BorderLayout.WEST);
        JPanel content = new JPanel(new BorderLayout(0, 17));
        content.setBackground(CARD);
        content.setBorder(new EmptyBorder(25, 26, 25, 26));
        content.add(fields, BorderLayout.NORTH);
        JPanel lower = vertical();
        checks.setAlignmentX(Component.LEFT_ALIGNMENT);
        checks.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        notice.setAlignmentX(Component.LEFT_ALIGNMENT);
        notice.setMaximumSize(new Dimension(Integer.MAX_VALUE, 54));
        lower.add(checks);
        lower.add(Box.createVerticalStrut(15));
        lower.add(notice);
        content.add(lower, BorderLayout.CENTER);
        JScrollPane scroll = new JScrollPane(content);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(CARD);
        scroll.getVerticalScrollBar().setUnitIncrement(18);
        root.add(scroll, BorderLayout.CENTER);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 13));
        footer.setBackground(GreenTheme.SOFT);
        footer.setBorder(new MatteBorder(1, 0, 0, 0, BORDER));
        JButton huy = button("Quay lại", false);
        JButton luu = button("Lưu thông tin", true);
        huy.addActionListener(e -> dialog.dispose());
        luu.addActionListener(e -> {
            String hoTen = ten.getText().trim();
            String phone = sdt.getText().trim();
            String id = cccd.getText().trim();
            String user = username.getText().trim().toLowerCase(Locale.ROOT);
            if (hoTen.isEmpty() || !phone.matches("0\\d{9}") || !id.matches("\\d{12}")) {
                warning(dialog, "Nhập họ tên, SĐT 10 chữ số và CCCD 12 chữ số hợp lệ.");
                return;
            }
            if (!user.matches("[a-z0-9_]{4,30}")) {
                warning(dialog, "Tên đăng nhập cần 4–30 ký tự: chữ thường, số hoặc gạch dưới.");
                return;
            }
            LocalDate birth, joined;
            try {
                birth = LocalDate.parse(ngaySinh.getText().trim(), DATE);
                joined = LocalDate.parse(ngayVao.getText().trim(), DATE);
            } catch (DateTimeParseException ex) {
                warning(dialog, "Ngày phải đúng định dạng dd/MM/yyyy.");
                return;
            }
            if (!birth.isBefore(joined) || birth.isAfter(LocalDate.now())) {
                warning(dialog, "Ngày sinh phải trước ngày vào làm và không ở tương lai.");
                return;
            }
            try {
                NhanVien data = new NhanVien();
                NhanVien snapshotCu = null;
                if (nvCu != null) {
                    data.setMaNV(nvCu.ma);
                    snapshotCu = bus.timTheoMa(nvCu.ma);
                }
                data.setHoTen(hoTen); data.setSdtNV(phone); data.setSoCCCD(id);
                data.setNgaySinh(birth); data.setNgayVaoLam(joined);
                data.setDiaChi(diaChi.getText().trim()); data.setDangLamViec(dangLam.isSelected());
                TaiKhoan tk = new TaiKhoan();
                if (nvCu != null) {
                    if (snapshotCu == null || snapshotCu.getTaiKhoan() == null)
                        throw new IllegalArgumentException("Không tìm thấy tài khoản cần sửa.");
                    tk.setMaTK(snapshotCu.getTaiKhoan().getMaTK());
                }
                tk.setTenDangNhap(user);
                tk.setVaiTro("Quản lý".equals(vaiTro.getSelectedItem())
                        ? VaiTro.QUAN_LY : VaiTro.NHAN_VIEN_BAN_HANG);
                tk.setDangHoatDong(dangLam.isSelected() && truyCap.isSelected());
                data.setTaiKhoan(tk);

                if (nvCu == null) {
                    NhanVien daTao = bus.themNhanVien(data);
                    QuanLyHoanTac.ghiNhan(
                        "Ngừng kích hoạt nhân viên vừa thêm " + daTao.getMaNV(),
                        () -> {
                            daTao.setDangLamViec(false);
                            daTao.getTaiKhoan().setDangHoatDong(false);
                            bus.capNhatNhanVien(daTao);
                        },
                        this::lamMoiTuCSDL
                    );
                } else {
                    if (!bus.capNhatNhanVien(data))
                        throw new IllegalArgumentException("Không tìm thấy hồ sơ cần cập nhật.");
                    final NhanVien banLuuCu = snapshotCu;
                    QuanLyHoanTac.ghiNhan(
                        "Khôi phục thông tin nhân viên " + banLuuCu.getMaNV(),
                        () -> bus.capNhatNhanVien(banLuuCu),
                        this::lamMoiTuCSDL
                    );
                }
                lamMoiTuCSDL();
            } catch (RuntimeException ex) {
                warning(dialog, ex.getMessage());
                return;
            }
            dialog.dispose();
        });
        footer.add(huy);
        footer.add(luu);
        root.add(footer, BorderLayout.SOUTH);
        dialog.setContentPane(root);
        dialog.setVisible(true);
    }

    private static JPanel stat(String title, JLabel value, String desc, Color accent) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(CARD);
        card.setBorder(new CompoundBorder(new LineBorder(BORDER), new EmptyBorder(14, 14, 14, 14)));
        JPanel lines = vertical();
        lines.add(text(title, 11, Font.PLAIN, MUTED));
        lines.add(Box.createVerticalStrut(8));
        lines.add(value);
        lines.add(Box.createVerticalStrut(6));
        lines.add(text(desc, 10, Font.PLAIN, MUTED));
        card.add(lines, BorderLayout.CENTER);
        card.add(text("●", 15, Font.BOLD, accent), BorderLayout.EAST);
        return card;
    }

    private static JPanel vertical() {
        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        return panel;
    }

    private static JLabel text(String value, int size, int style, Color color) {
        JLabel l = new JLabel(value);
        l.setFont(new Font("SansSerif", style, size));
        l.setForeground(color);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    private static JButton button(String title, boolean primary) {
        JButton b = new JButton(title);
        b.setFont(new Font("SansSerif", Font.BOLD, 11));
        b.setBackground(primary ? ACCENT : GreenTheme.SOFT);
        b.setForeground(primary ? Color.WHITE : TEXT);
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBorder(new CompoundBorder(new LineBorder(primary ? ACCENT : BORDER),
                new EmptyBorder(9, 12, 9, 12)));
        return b;
    }

    private static JTextField input(String value) {
        JTextField f = new JTextField(value);
        styleInput(f);
        return f;
    }

    private static void styleInput(JTextField f) {
        f.setBackground(GreenTheme.SURFACE);
        f.setForeground(TEXT);
        f.setCaretColor(TEXT);
        f.setFont(new Font("SansSerif", Font.PLAIN, 12));
        f.setBorder(new CompoundBorder(new LineBorder(BORDER), new EmptyBorder(8, 11, 8, 11)));
        f.setPreferredSize(new Dimension(160, 36));
    }

    private static void styleCombo(JComboBox<String> c) {
        c.setBackground(GreenTheme.SURFACE);
        c.setForeground(TEXT);
        c.setFont(new Font("SansSerif", Font.PLAIN, 11));
        c.setPreferredSize(new Dimension(155, 36));
    }

    private static JPanel field(String caption, JComponent comp) {
        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.setOpaque(false);
        p.add(text(caption, 12, Font.BOLD, MUTED), BorderLayout.NORTH);
        p.add(comp, BorderLayout.CENTER);
        return p;
    }

    private static JCheckBox checkbox(String caption, boolean selected) {
        JCheckBox c = new JCheckBox(caption, selected);
        c.setOpaque(false);
        c.setForeground(MUTED);
        c.setFont(new Font("SansSerif", Font.PLAIN, 11));
        return c;
    }

    private static String escape(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private static void warning(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Kiểm tra dữ liệu", JOptionPane.WARNING_MESSAGE);
    }

    private static class DongNhanVien {
        final String ma;
        String hoTen, sdt, cccd, vaiTro, tenDangNhap, diaChi;
        LocalDate ngaySinh, ngayVaoLam;
        boolean dangLamViec, choPhepTruyCap;

        DongNhanVien(String ma, String hoTen, String sdt, String cccd,
                LocalDate ngaySinh, LocalDate ngayVaoLam, String vaiTro, String tenDangNhap,
                String diaChi, boolean dangLamViec, boolean choPhepTruyCap) {
            this.ma = ma;
            this.hoTen = hoTen;
            this.sdt = sdt;
            this.cccd = cccd;
            this.ngaySinh = ngaySinh;
            this.ngayVaoLam = ngayVaoLam;
            this.vaiTro = vaiTro;
            this.tenDangNhap = tenDangNhap;
            this.diaChi = diaChi;
            this.dangLamViec = dangLamViec;
            this.choPhepTruyCap = choPhepTruyCap;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}