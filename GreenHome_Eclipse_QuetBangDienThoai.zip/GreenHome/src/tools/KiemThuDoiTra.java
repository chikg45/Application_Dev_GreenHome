package tools;

import bus.DoiTraBUS;
import dao.DoiTraDAO;
import dao.GiaoDichDoiTraDAO.SanPhamThay;
import database.DatabaseConnection;
import java.math.BigDecimal;
import java.sql.*;
import java.util.*;

/** Chạy trên bản GreenHome_QA mới, độc lập. Giữ dữ liệu kiểm thử để đối chiếu. */
public final class KiemThuDoiTra {
    private static final String HD="HD90000001", NV="NV9001";
    private static final BigDecimal ZERO=BigDecimal.ZERO;
    private interface Buoc {void run() throws Exception;}
    private static void chan(Buoc viec) throws Exception {
        try {viec.run();} catch(IllegalArgumentException expected){return;}
        throw new AssertionError("Một thao tác không hợp lệ đã được chấp nhận.");
    }
    private static void check(boolean ok,String message){if(!ok) throw new AssertionError(message);}
    private static void duLieu(Connection c) throws SQLException {
        var records=List.of(
            "INSERT dbo.NhanVien(maNV,hoTen,sdtNV,soCCCD,ngaySinh,ngayVaoLam,dangLamViec) VALUES ('NV9001',N'Nhân viên QA','0900009001','000000009001','19950101','20200101',1)",
            "INSERT dbo.TaiKhoan(maTK,tenDangNhap,matKhau,vaiTro,maNV,dangHoatDong) VALUES ('TK9001','qa_nv','qa-disabled-password','NHAN_VIEN_BAN_HANG','NV9001',1)",
            "INSERT dbo.ThuongHieu(maTH,tenTH) VALUES ('TH901',N'Hãng QA')",
            "INSERT dbo.KhachHang(maKH,tenKH,sdtKH,diemTichLuy) VALUES ('KH90000001',N'Khách QA','0900009002',0)",
            "INSERT dbo.SanPham(maSP,tenSP,maDM,maTH,giaNiemYet,donViTinh,tinhTrang,soLuongTon,soLuongLoi,soLuongTonToiThieu) VALUES ('QA01',N'Hàng QA','DM001','TH901',100.25,N'Cái','DANG_KINH_DOANH',10,1,0)",
            "INSERT dbo.HoaDon(maHD,ngayLap,phuongThucThanhToan,maKH,maNV) VALUES ('HD90000001',SYSDATETIME(),'TIEN_MAT','KH90000001','NV9001')",
            "INSERT dbo.ChiTietHoaDon(maHD,maSP,soLuong,donGia,soTienGiam,serialIMEI) VALUES ('HD90000001','QA01',4,100.25,0,'TESTSERIAL')"
        );
        c.setAutoCommit(false);
        try(Statement st=c.createStatement()){
            for(String sql:records) st.executeUpdate(sql);
            c.commit();
        } catch(SQLException e){c.rollback();throw e;}
    }
    private static String gui(int id,String cu,String kieu) throws SQLException {
        return DoiTraBUS.guiPhieu(cu,HD,NV,"Khách QA","0900009002","Kiểm tra yêu cầu đổi trả",
            "Nguyên vẹn","Đủ phụ kiện",kieu,"CON_NGUYEN_VEN",List.of(new DoiTraDAO.DongTraInfo(id,1)));
    }
    private static DoiTraDAO.PhieuInfo phieu(String ma) throws SQLException {
        return DoiTraBUS.danhSachPhieu().stream().filter(p->p.ma().equals(ma)).findFirst().orElseThrow();
    }
    public static void main(String[] args) throws Exception {
        try(Connection c=DatabaseConnection.getConnection()){
            if(!"GreenHome_QA".equalsIgnoreCase(c.getCatalog()))throw new IllegalStateException("Chỉ chạy trên GreenHome_QA mới.");
            duLieu(c);
        }
        int id=DoiTraBUS.danhSachHoaDon().stream().filter(h->HD.equals(h.ma())).findFirst().orElseThrow().dongs().get(0).id();
        String tra=gui(id,null,"HOAN_TIEN");
        var tong=DoiTraBUS.tinhGiaoDich(phieu(tra).chiTiet(),Map.of());
        check(tong.hoan().compareTo(new BigDecimal("100.25"))==0,"Mất phần thập phân");
        check("TESTSERIAL".equals(phieu(tra).chiTiet().get(0).serial()),"Thiếu serial");
        chan(()->DoiTraBUS.xetDuyet(tra,NV,true));
        DoiTraBUS.xetDuyet(tra,"NV0001",false);
        chan(()->DoiTraBUS.hoanTat(tra,NV,Map.of(),tong.hoan(),tong,"TIEN_MAT"));
        gui(id,tra,"HOAN_TIEN");
        DoiTraBUS.xetDuyet(tra,"NV0001",true);
        DoiTraBUS.hoanTat(tra,NV,Map.of(),new BigDecimal("99.99"),tong,"TIEN_MAT");
        chan(()->DoiTraBUS.hoanTat(tra,NV,Map.of(),tong.hoan(),tong,"TIEN_MAT"));
        var history=DoiTraBUS.lichSu(tra);
        check(history.size()==5 && history.get(4).thucHoan().compareTo(new BigDecimal("99.99"))==0,"Sai lịch sử hoàn tiền");
        var han=java.time.LocalDate.of(2026,1,1);
        check(entity.PhieuDoiTra.trongHan(han,han.plusDays(7)) && !entity.PhieuDoiTra.trongHan(han,han.plusDays(8))
                && !entity.PhieuDoiTra.trongHan(han,han.minusDays(1)),"Sai biên 7 ngày");
        check(DoiTraBUS.phanBo(new BigDecimal("10.00"),3,1).compareTo(new BigDecimal("3.33"))==0
                && DoiTraBUS.phanBo(new BigDecimal("6.67"),2,2).compareTo(new BigDecimal("6.67"))==0,"Sai phân bổ phần lẻ");
        int kho=10;
        for(String gia:List.of("120.50","100.25","87.50")){
            String doi=gui(id,null,"DOI_SAN_PHAM");
            DoiTraBUS.xetDuyet(doi,"NV0001",true);
            try(Connection c=DatabaseConnection.getConnection()){
                connectDB.Jdbc.capNhat(c,"UPDATE dbo.SanPham SET giaNiemYet=? WHERE maSP='QA01'",new BigDecimal(gia));
            }
            var sp=DoiTraBUS.sanPhamThay().stream().filter(s->s.ma().equals("QA01")).findFirst().orElseThrow();
            var rows=phieu(doi).chiTiet();var thay=Map.of(id,sp);
            var chenh=DoiTraBUS.tinhGiaoDich(rows,thay);
            check(chenh.chenh().compareTo(new BigDecimal(gia).subtract(new BigDecimal("100.25")))==0,"Sai chênh lệch");
            var giaCu=Map.of(id,new SanPhamThay(sp.ma(),sp.ten(),sp.gia().add(BigDecimal.ONE),sp.ton()));
            chan(()->DoiTraBUS.hoanTat(doi,NV,giaCu,ZERO,DoiTraBUS.tinhGiaoDich(rows,giaCu),"TIEN_MAT"));
            check("DA_DUYET".equals(phieu(doi).trangThai()),"Phiếu phải rollback khi giá đổi");
            try(Connection c=DatabaseConnection.getConnection()){
                connectDB.Jdbc.capNhat(c,"UPDATE dbo.SanPham SET soLuongLoi=soLuongTon WHERE maSP='QA01'");
            }
            chan(()->DoiTraBUS.hoanTat(doi,NV,thay,ZERO,chenh,"CHUYEN_KHOAN"));
            check("DA_DUYET".equals(phieu(doi).trangThai()),"Phiếu phải rollback khi hết tồn");
            try(Connection c=DatabaseConnection.getConnection()){
                connectDB.Jdbc.capNhat(c,"UPDATE dbo.SanPham SET soLuongLoi=1 WHERE maSP='QA01'");
            }
            if(gia.equals("87.50")) {
                var gate=new java.util.concurrent.CountDownLatch(1);
                java.util.concurrent.Callable<Integer> xacNhan=()->{
                    gate.await();
                    try {DoiTraBUS.hoanTat(doi,NV,thay,ZERO,chenh,"CHUYEN_KHOAN");return 1;}
                    catch(IllegalArgumentException daXuLy){return 0;}
                };
                try(var pool=java.util.concurrent.Executors.newFixedThreadPool(2)){
                    var a=pool.submit(xacNhan);var b=pool.submit(xacNhan);gate.countDown();
                    check(a.get()+b.get()==1,"Hai quầy xác nhận cùng lúc phải ghi đúng một lần");
                }
            } else DoiTraBUS.hoanTat(doi,NV,thay,ZERO,chenh,"CHUYEN_KHOAN");
            chan(()->DoiTraBUS.hoanTat(doi,NV,thay,ZERO,chenh,"CHUYEN_KHOAN"));
            var ct=phieu(doi).chiTiet().get(0);
            check("QA01".equals(ct.maThay()) && sp.gia().compareTo(ct.giaThay())==0,"Thiếu hàng thay thế");
            kho--;
            var available=DoiTraBUS.sanPhamThay().stream().filter(s->s.ma().equals("QA01")).findFirst().orElseThrow();
            check(available.ton()==kho-1,"Sai tồn có thể bán");
        }
        chan(()->gui(id,null,"HOAN_TIEN"));
        System.out.println("PASS: tiếp nhận, quyền duyệt, từ chối, gửi lại, hoàn tiền, 3 mức giá đổi, rollback, tồn, serial, lịch sử và chặn trùng.");
    }
}
