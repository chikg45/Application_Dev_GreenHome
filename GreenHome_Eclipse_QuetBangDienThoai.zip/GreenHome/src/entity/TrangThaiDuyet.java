package entity;

public enum TrangThaiDuyet {
    CHO_DUYET,
    DA_DUYET,
    TU_CHOI,
    HOAN_TAT
}
