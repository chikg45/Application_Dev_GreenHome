package camera;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.net.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public final class DienThoaiDialog {
    private record Mang(String ten, Inet4Address ip) {
        @Override public String toString() { return ten+" · "+ip.getHostAddress(); }
    }
    private final JDialog dialog;
    private final JLabel qr=new JLabel("",SwingConstants.CENTER);
    private final JTextField link=new JTextField(32);
    private final JLabel status=new JLabel(" ");
    private final JLabel guide=new JLabel("Quét QR bằng camera điện thoại, rồi bấm Kết nối quầy.");
    private final PhienCamera.Quet quet;
    private PhienCamera session;

    private DienThoaiDialog(Component parent,PhienCamera.Quet quet,List<Mang> mang){
        this.quet=quet;
        dialog=new JDialog(SwingUtilities.getWindowAncestor(parent),"Máy quét điện thoại",Dialog.ModalityType.APPLICATION_MODAL);
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        JPanel body=new JPanel();
        body.setLayout(new BoxLayout(body,BoxLayout.Y_AXIS));
        body.setBorder(new EmptyBorder(16,18,16,18));
        JComboBox<Mang> networks=new JComboBox<>(mang.toArray(Mang[]::new));
        link.setEditable(false);
        link.addMouseListener(new MouseAdapter(){@Override public void mouseClicked(MouseEvent e){link.selectAll();}});
        status.putClientProperty("html.disable",Boolean.TRUE);
        status.setForeground(new Color(0x166342));
        JButton close=new JButton("Kết thúc quét và trở về giỏ");
        close.addActionListener(e->dialog.dispose());
        for(JComponent c:new JComponent[]{new JLabel("Mạng kết nối với điện thoại"),networks,guide,qr,link,status,close}){
            c.setAlignmentX(Component.CENTER_ALIGNMENT); body.add(c);body.add(Box.createVerticalStrut(8));
        }
        dialog.setContentPane(body);
        networks.addActionListener(e->open((Mang)networks.getSelectedItem()));
        open(mang.get(0));
        dialog.pack();dialog.setLocationRelativeTo(parent);
    }
    private void open(Mang network){
        if(session!=null){session.close();session=null;}
        guide.setVisible(true);qr.setVisible(true);link.setVisible(true);
        try{
            session=new PhienCamera(network.ip,quet,text->{
                status.setText(text);qr.setVisible(false);link.setVisible(false);guide.setVisible(false);
                dialog.pack();
            },dialog::dispose);
            String url=session.diaChi().toASCIIString();
            qr.setIcon(new ImageIcon(MaGhepNoi.ve(url)));link.setText(url);
            status.setText("Đang chờ điện thoại trên cùng mạng Wi-Fi / LAN.");
        }catch(IOException ex){
            qr.setIcon(null);link.setText("");status.setText("Không mở được kết nối: "+ex.getMessage());
        }
        dialog.pack();
    }
    public static void mo(Component parent,PhienCamera.Quet quet){
        try{
            List<Mang> choices=new ArrayList<>();
            for(NetworkInterface n: Collections.list(NetworkInterface.getNetworkInterfaces())){
                if(!n.isUp()||n.isLoopback())continue;
                for(InetAddress a: Collections.list(n.getInetAddresses())){
                    if(a instanceof Inet4Address ip && !ip.isLinkLocalAddress() && !ip.isLoopbackAddress())
                        choices.add(new Mang(n.getDisplayName(),ip));
                }
            }
            choices.sort(Comparator.comparingInt((Mang m)->m.ten.toLowerCase(java.util.Locale.ROOT)
                    .matches(".*(wi-fi|wireless|wlan).*")?0:m.ip.isSiteLocalAddress()?1:2));
            if(choices.isEmpty()){
                JOptionPane.showMessageDialog(parent,"Hãy kết nối máy tính và điện thoại vào cùng Wi-Fi hoặc LAN rồi bấm quét lại.");return;
            }
            DienThoaiDialog view=new DienThoaiDialog(parent,quet,choices);
            try{view.dialog.setVisible(true);}
            finally{if(view.session!=null)view.session.close();view.dialog.dispose();}
        }catch(SocketException ex){JOptionPane.showMessageDialog(parent,"Không đọc được địa chỉ mạng: "+ex.getMessage());}
    }
}
