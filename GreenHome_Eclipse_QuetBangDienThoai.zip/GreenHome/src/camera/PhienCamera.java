package camera;

import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;
import javax.swing.SwingUtilities;

/** One temporary LAN address, one paired phone and one in-progress sale. */
public final class PhienCamera implements AutoCloseable {
    @FunctionalInterface public interface Quet { String nhan(String code,String sku) throws Exception; }
    private record Receipt(String action,String code,String sku,String text) {}
    private final HttpServer server;
    private final String path="/"+UUID.randomUUID()+"/";
    private final URI uri;
    private final Quet reader;
    private final Consumer<String> display;
    private final Runnable finish;
    private final Map<String,Receipt> receipts=new HashMap<>();
    private String device, pendingCode;
    private volatile boolean closed;

    PhienCamera(InetAddress address,Quet reader,Consumer<String> display,Runnable finish) throws IOException {
        this.reader=reader;this.display=display;this.finish=finish;
        server=HttpServer.create(new InetSocketAddress(address,0),8);
        uri=URI.create("http://"+address.getHostAddress()+":"+server.getAddress().getPort()+path);
        server.createContext(path,this::handle);
        // The server's default single dispatcher serializes pairing and all scan receipts.
        server.start();
    }
    URI diaChi(){return uri;}
    private void handle(HttpExchange x) throws IOException {
        try(x) {
            try {dispatch(x);}
            catch(IllegalArgumentException ex) {reply(x,400,"Yêu cầu không hợp lệ.");}
        }
    }
    private void dispatch(HttpExchange x) throws IOException {
        String action=x.getRequestURI().getRawPath().substring(path.length());
        if(closed || !uri.getAuthority().equals(x.getRequestHeaders().getFirst("Host"))) {
            reply(x,403,"Phiên không hợp lệ.");return;
        }
        if("GET".equals(x.getRequestMethod())) {
            String file=switch(action) {case "" -> "index.html"; case "scan.js","decoder.js" -> action; default -> null;};
            if(file==null){reply(x,404,"");return;}
            try(InputStream in=PhienCamera.class.getResourceAsStream("/camera/"+file)){
                if(in==null){reply(x,500,"Thiếu tệp giao diện điện thoại.");return;}
                x.getResponseHeaders().set("Content-Type",file.endsWith(".js")?"text/javascript; charset=utf-8":"text/html; charset=utf-8");
                x.getResponseHeaders().set("Content-Security-Policy","default-src 'self'; img-src 'self' blob:; style-src 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'");
                reply(x,200,new String(in.readAllBytes(),StandardCharsets.UTF_8));
            }
            return;
        }
        if(!"POST".equals(x.getRequestMethod()) ||
                !("http://"+uri.getAuthority()).equals(x.getRequestHeaders().getFirst("Origin"))) {
            reply(x,403,"Nguồn yêu cầu không hợp lệ.");return;
        }
        byte[] body=x.getRequestBody().readNBytes(4097);
        if(body.length>4096){reply(x,413,"Dữ liệu quá dài.");return;}
        Map<String,String> f=new HashMap<>();
        for(String part:new String(body,StandardCharsets.UTF_8).split("&")) {
            String[] pair=part.split("=",2);
            if(pair.length==2) f.put(pair[0],URLDecoder.decode(pair[1],StandardCharsets.UTF_8));
        }
        String key=f.getOrDefault("device","");
        if(!key.matches("[a-f0-9]{32}")){reply(x,403,"Thiếu mã ghép nối.");return;}
        if(action.equals("pair") && device==null) {
            device=key; notifyCashier("Đã kết nối điện thoại. Sẵn sàng quét.");
        }
        if(!key.equals(device)){reply(x,409,"Phiên này đã ghép với điện thoại khác.");return;}
        if(action.equals("pair") || action.equals("ping")){reply(x,200,"OK");return;}
        if(action.equals("finish")){closed=true;try{reply(x,200,"OK");}finally{SwingUtilities.invokeLater(finish);}return;}
        if(!Set.of("scan","bind").contains(action)){reply(x,404,"");return;}
        String id=f.getOrDefault("id",""),code=f.getOrDefault("code","").strip(),sku=f.getOrDefault("sku","");
        if(!id.matches("[a-f0-9]{32}")||code.isBlank()||code.length()>128||sku.length()>20||(action.equals("bind") ? sku.isBlank() : !sku.isEmpty())){
            reply(x,400,"Mã đọc không hợp lệ.");return;
        }
        Receipt previous=receipts.get(id);
        if(previous!=null) {
            if(!previous.action.equals(action)||!previous.code.equals(code)||!previous.sku.equals(sku)){
                reply(x,409,"Lượt quét đã được sử dụng.");return;
            }
            reply(x,200,previous.text);return;
        }
        if(action.equals("bind")&&!code.equals(pendingCode)){reply(x,409,"Quét lại tem cần gắn.");return;}
        if(receipts.size()>=4000){reply(x,409,"Đóng phiên và ghép lại để tiếp tục.");return;}
        FutureTask<String> task=new FutureTask<>(()->{
            if(closed)throw new IllegalStateException("Phiên đã đóng.");
            return reader.nhan(code,sku);
        });
        SwingUtilities.invokeLater(task);
        String result;
        try{result=task.get();}
        catch(ExecutionException ex){result="Chưa thêm vào giỏ. "+Objects.toString(ex.getCause().getMessage(),"Hãy kiểm tra tại quầy.");}
        catch(InterruptedException ex){Thread.currentThread().interrupt();return;}
        boolean unknown=result.startsWith("UNKNOWN\n");
        pendingCode=unknown?code:null;
        receipts.put(id,new Receipt(action,code,sku,result));
        notifyCashier(unknown?"Tem "+code+" chưa gắn sản phẩm. Chọn sản phẩm trên điện thoại.":result);
        reply(x,200,result);
    }
    private void notifyCashier(String text) {SwingUtilities.invokeLater(()->{if(!closed)display.accept(text);});}
    private static void reply(HttpExchange x,int status,String text) throws IOException {
        byte[] b=text.getBytes(StandardCharsets.UTF_8);
        x.getResponseHeaders().putIfAbsent("Content-Type",List.of("text/plain; charset=utf-8"));
        x.getResponseHeaders().set("Cache-Control","no-store");
        x.getResponseHeaders().set("Referrer-Policy","no-referrer");
        x.getResponseHeaders().set("X-Content-Type-Options","nosniff");
        x.sendResponseHeaders(status,b.length);
        x.getResponseBody().write(b);
    }
    @Override public void close(){closed=true;CompletableFuture.runAsync(()->server.stop(0));}
}
