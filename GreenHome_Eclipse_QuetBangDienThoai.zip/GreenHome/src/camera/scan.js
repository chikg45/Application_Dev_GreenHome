'use strict';
const $=id=>document.getElementById(id);
const prefix='greenhome'+location.pathname;
const token=()=>Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,'0')).join('');
const get=k=>localStorage.getItem(prefix+k);
const save=(k,v)=>localStorage.setItem(prefix+k,v);
const remove=k=>localStorage.removeItem(prefix+k);
let device, connected=false, busy=false, unknown=null;
function say(text){$('status').textContent=text;}
function controls(){
    $('pair').hidden=connected;
    $('scanner').hidden=!connected || busy || unknown!==null || !!get('pending');
    $('mapping').hidden=!connected || busy || unknown===null || !!get('pending');
    $('retry').hidden=!connected || busy || !get('pending');
    $('finish').hidden=!connected || busy;
}
async function post(path,params={}){
    const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),16000);
    try{
        const r=await fetch(path,{method:'POST',body:new URLSearchParams({device,...params}),signal:abort.signal});
        const text=await r.text();
        if(!r.ok){const e=new Error(text || 'Phiên đã đóng.');e.status=r.status;throw e;}
        return text;
    }finally{clearTimeout(timer);}
}
async function send(op){
    busy=true;save('pending',JSON.stringify(op));controls();
    try{
        const text=await post(op.action,op);
        if(text.startsWith('UNKNOWN\n')){
            unknown=op.code;
            const list=text.slice(8).split('\n').filter(Boolean);
            $('products').replaceChildren(new Option('Chọn sản phẩm…',''));
            for(const line of list){
                const [ma,ten]=line.split('\t').map(decodeURIComponent);
                $('products').add(new Option(ma+' · '+ten,ma));
            }
            say('Tem '+op.code+' chưa được gắn. Chọn sản phẩm rồi bấm Gắn mã và thêm 1.');
            save('mapping',JSON.stringify(op));
        }else{
            unknown=null;remove('mapping');say(text);
        }
        remove('pending');
    }catch(e){
        if(e.status){remove('pending');remove('mapping');unknown=null;say(e.message);}
        else say('Chưa nhận xác nhận từ quầy. Kiểm tra Wi-Fi rồi bấm Gửi lại lượt vừa quét.');
    }finally{busy=false;controls();}
}
function scan(code,id=token()){
    return send({action:'scan',id,code,sku:''});
}
async function pair(){
    try{
        $('pair').disabled=true;
        await post('pair');connected=true;save('paired','1');say('Đã kết nối. Chọn cách quét mã sản phẩm.');
        controls();
        const fragment=new URLSearchParams(location.hash.slice(1));
        if(fragment.has('code')){
            const id=fragment.get('id'),code=fragment.get('code');
            if(id && id===get('nativeId') && code){
                const op={action:'scan',id,code,sku:''};
                save('pending',JSON.stringify(op));
            }
            remove('nativeId');history.replaceState(null,'',location.pathname);
        }
        // A lost response or a page reload must reuse the same receipt ID.
        const pending=get('pending')||get('mapping');
        if(pending)await send(JSON.parse(pending));
    }catch(e){
        say(e.status?e.message:'Chưa kết nối được. Kiểm tra Wi-Fi và phiên trên máy tính.');
    }finally{$('pair').disabled=false;controls();}
}
// Decode several lines in each orientation. Only the decoded text is transmitted.
async function fromPhoto(file){
    const url=URL.createObjectURL(file);
    try{
        const im=new Image();im.src=url;await im.decode();
        const scale=Math.min(1,2200/Math.max(im.naturalWidth,im.naturalHeight));
        const w=Math.max(1,Math.round(im.naturalWidth*scale)),h=Math.max(1,Math.round(im.naturalHeight*scale));
        const c=document.createElement('canvas');c.width=w;c.height=h;
        const ctx=c.getContext('2d',{willReadFrequently:true});ctx.drawImage(im,0,0,w,h);
        const pixels=ctx.getImageData(0,0,w,h).data;
        for(const vertical of [false,true]){
            const len=vertical?h:w,across=vertical?w:h,step=vertical?w:1;
            const row=new Uint8Array(len);
            for(let j=0;j<39;j++){
                const f=0.5+(j%2===0?1:-1)*Math.ceil(j/2)*0.024;
                const k=Math.floor(across*f);
                let offset=4*(vertical?k:k*w);
                for(let i=0;i<len;i++,offset+=4*step)row[i]=(pixels[offset]+2*pixels[offset+1]+pixels[offset+2])>>2;
                const code=decodeRow(row);if(code)return code;
            }
        }
        return null;
    }finally{URL.revokeObjectURL(url);}
}
$('pair').onclick=pair;
$('photo').onclick=()=>$('image').click();
$('image').onchange=async()=>{
    const file=$('image').files[0];$('image').value='';
    if(!file||busy)return;
    busy=true;controls();say('Đang đọc tem…');
    try{
        const code=await fromPhoto(file);
        if(code)await scan(code);else say('Chưa đọc được mã. Chụp gần hơn, đủ sáng và lấy trọn hai đầu tem.');
    }catch{say('Không đọc được ảnh này. Hãy chụp lại tem.');}
    finally{busy=false;controls();}
};
$('native').hidden=!/android/i.test(navigator.userAgent);
$('native').href='binaryeye://scan';
$('native').onclick=e=>{
    e.preventDefault();
    const id=token();save('nativeId',id);
    const ret=location.origin+location.pathname+'#id='+id+'&code={RESULT}';
    say('Đưa tem vào khung Binary Eye. Nếu điện thoại chưa cài ứng dụng, chọn Chụp mã vạch.');
    location.href='binaryeye://scan?ret='+encodeURIComponent(ret);
};
$('bind').onclick=()=>{if(unknown && $('products').value)send({action:'bind',id:token(),code:unknown,sku:$('products').value});};
$('skip').onclick=()=>{unknown=null;remove('mapping');say('Đã bỏ qua tem.');controls();};
$('retry').onclick=()=>{const op=get('pending');if(op)send(JSON.parse(op));};
$('finish').onclick=async()=>{
    busy=true;controls();
    try{await post('finish');connected=false;['pending','mapping','paired','nativeId','device'].forEach(remove);
        say('Đã kết thúc. Bạn có thể thanh toán tại quầy.');$('pair').disabled=true;}
    catch{say('Chưa xác nhận kết thúc. Bạn có thể đóng phiên trên máy tính.');}
    finally{busy=false;controls();}
};
try{
    device=get('device')||token();save('device',device);
    if(get('paired')==='1'||location.hash)pair();
}catch{$('pair').disabled=true;say('Hãy mở liên kết bằng trình duyệt cho phép lưu dữ liệu trang.');}

window.addEventListener('hashchange',()=>{if(location.hash&&!busy)pair();});
