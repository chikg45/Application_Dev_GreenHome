// Decode horizontal scan lines from a local camera frame, in either direction.
const CODE128 = '212222 222122 222221 121223 121322 131222 122213 122312 132212 221213 221312 231212 112232 122132 122231 113222 123122 123221 223211 221132 221231 213212 223112 312131 311222 321122 321221 312212 322112 322211 212123 212321 232121 111323 131123 131321 112313 132113 132311 211313 231113 231311 112133 112331 132131 113123 113321 133121 313121 211331 231131 213113 213311 213131 311123 311321 331121 312113 312311 332111 314111 221411 431111 111224 111422 121124 121421 141122 141221 112214 112412 122114 122411 142112 142211 241211 221114 413111 241112 134111 111242 121142 121241 114212 124112 124211 411212 421112 421211 212141 214121 412121 111143 111341 131141 114113 114311 411113 411311 113141 114131 311141 411131 211412 211214 211232 2331112'.split(' ');
const CODE39 = {"0": "nnnWWnWnn", "1": "WnnWnnnnW", "2": "nnWWnnnnW", "3": "WnWWnnnnn", "4": "nnnWWnnnW", "5": "WnnWWnnnn", "6": "nnWWWnnnn", "7": "nnnWnnWnW", "8": "WnnWnnWnn", "9": "nnWWnnWnn", "A": "WnnnnWnnW", "B": "nnWnnWnnW", "C": "WnWnnWnnn", "D": "nnnnWWnnW", "E": "WnnnWWnnn", "F": "nnWnWWnnn", "G": "nnnnnWWnW", "H": "WnnnnWWnn", "I": "nnWnnWWnn", "J": "nnnnWWWnn", "K": "WnnnnnnWW", "L": "nnWnnnnWW", "M": "WnWnnnnWn", "N": "nnnnWnnWW", "O": "WnnnWnnWn", "P": "nnWnWnnWn", "Q": "nnnnnnWWW", "R": "WnnnnnWWn", "S": "nnWnnnWWn", "T": "nnnnWnWWn", "U": "WWnnnnnnW", "V": "nWWnnnnnW", "W": "WWWnnnnnn", "X": "nWnnWnnnW", "Y": "WWnnWnnnn", "Z": "nWWnWnnnn", "-": "nWnnnnWnW", ".": "WWnnnnWnn", " ": "nWWnnnWnn", "*": "nWnnWnWnn", "$": "nWnWnWnnn", "/": "nWnWnnnWn", "+": "nWnnnWnWn", "%": "nnnWnWnWn"};
const L = ['3211','2221','2122','1411','1132','1231','1114','1312','1213','3112'];
const G = L.map(s => [...s].reverse().join(''));
const PARITY = ['LLLLLL','LLGLGG','LLGGLG','LLGGGL','LGLLGG','LGGLLG','LGGGLL','LGLGLG','LGLGGL','LGGLGL'];

function errorAt(runs, i, pattern) {
    if (i + pattern.length > runs.length) return Infinity;
    let total = 0, modules = 0;
    for (let j=0; j<pattern.length; j++) { total += runs[i+j]; modules += Number(pattern[j]); }
    const unit = total / modules;
    let error = 0;
    for (let j=0; j<pattern.length; j++) {
        const d = Math.abs(runs[i+j] / unit - Number(pattern[j]));
        if (d > 0.82) return Infinity;
        error += d;
    }
    return error / modules;
}
function symbol(runs, i, patterns) {
    let best=-1, score=0.20;
    for(let j=0;j<patterns.length;j++) {
        const error=errorAt(runs,i,patterns[j]);
        if(error<score) { best=j; score=error; }
    }
    return best;
}
function code128(r,i) {
    let start=symbol(r,i,CODE128.slice(103,106));
    if(start<0) return null;
    const data=[];
    i+=6;
    for(;data.length<132;i+=6) {
        if(errorAt(r,i,CODE128[106])<0.17 && (i+7===r.length || r[i+7]>=r[i+6]*1.4)) break;
        const digit=symbol(r,i,CODE128.slice(0,103));
        if(digit<0) return null;
        data.push(digit);
    }
    if(data.length<2 || data.length>=132) return null;
    const check=data.pop();
    if((data.reduce((a,v,k)=>a+v*(k+1),103+start)%103)!==check) return null;
    let set=start, result='', shift=false;
    for(const v of data) {
        if(set===2 && v<100) {result+=String(v).padStart(2,'0');continue;}
        if(v===99) {set=2;continue;}
        if(v===100) {if(set===1)return null;set=1;continue;}
        if(v===101) {if(set===0)return null;set=0;continue;}
        if(v===98) {shift=true;continue;}
        if(v>=96)return null;
        const use=shift?1-set:set; shift=false;
        result+=String.fromCharCode(use===0 && v>=64?v-64:v+32);
    }
    return result && !shift && !/[\x00-\x1f\x7f]/.test(result)?result:null;
}
function retail(r,i,n) {
    if(errorAt(r,i,'111')>0.17)return null;
    const half=n===8?4:6;
    let value='',parity='';
    i+=3;
    for(let j=0;j<half;j++,i+=4){
        const digit=symbol(r,i,n===8?L:L.concat(G)); if(digit<0)return null;
        parity+=digit<10?'L':'G'; value+=digit%10;
    }
    if(n===13) {const lead=PARITY.indexOf(parity);if(lead<0)return null;value=lead+value;}
    if(errorAt(r,i,'11111')>0.17)return null;
    i+=5;
    for(let j=0;j<half;j++,i+=4){const d=symbol(r,i,L);if(d<0)return null;value+=d;}
    if(errorAt(r,i,'111')>0.17 || (i+3<r.length && r[i+3]<r[i+2]*2))return null;
    return [...value].reverse().reduce((a,v,k)=>a+Number(v)*(k%2?3:1),0)%10===0?value:null;
}
function code39(r,i) {
    const chars=Object.keys(CODE39);
    function read(k) {
        const widths=r.slice(k,k+9);
        if(widths.length!==9)return null;
        const sorted=[...widths].sort((a,b)=>a-b);
        if(sorted[6]<sorted[5]*1.35 || sorted[8]>sorted[0]*5)return null;
        const pattern=widths.map(w=>w>=sorted[6]?'W':'n').join('');
        return chars.find(c=>CODE39[c]===pattern);
    }
    if(read(i)!=='*')return null;
    let text='';
    for(i+=10;text.length<128;i+=10) {
        const c=read(i);
        if(!c)return null;
        if(c==='*') return text||null;
        text+=c;
    }
    return null;
}
function decodeRow(gray) {
    let lo=255,hi=0;
    for(const v of gray){lo=Math.min(lo,v);hi=Math.max(hi,v);}
    if(hi-lo<44)return null;
    const mid=(lo+hi)/2;
    let dark=gray[0]<mid, length=0, runs=[];
    if(dark)runs.push(0);
    for(const v of gray) {
        if((v<mid)!==dark){runs.push(length);dark=!dark;length=0;}
        length++;
    }
    runs.push(length);
    if(dark)runs.push(0);
    for(const row of [runs,[...runs].reverse()]){
        for(let i=1;i+16<row.length;i+=2) {
            if(row[i-1]<row[i]*1.5)continue;
            const hit=code128(row,i)||retail(row,i,13)||retail(row,i,8)||code39(row,i);
            if(hit)return hit;
        }
    }
    return null;
}
