# Chạy GreenHome trong Eclipse

**Nếu đang dùng bản cũ**, đóng ứng dụng, sao lưu database và giữ lại `config/db.properties` trên máy. Mở **File → Switch Workspace → Other** để chọn một workspace mới, rồi import ZIP theo bước 1. Sau khi import, chép cấu hình kết nối cũ vào `GreenHome/config/db.properties` và chạy script nâng cấp ở bước 2. Cả hai workspace có thể trỏ tới cùng database, nên dùng bản mới sau khi nâng cấp.

## 1. Import project

Dùng Eclipse IDE for Java Developers hỗ trợ Java 21 và JDK 21. Trong **File → Import → General → Existing Projects into Workspace**, chọn **Select archive file**, trỏ tới `GreenHome_Eclipse_QuetMa_DoiTra.zip`, tích **GreenHome** và nhấn **Finish**. Driver Microsoft JDBC có sẵn trong `lib`.

Nếu Eclipse báo thiếu **JavaSE-21**, mở **Window → Preferences → Java → Installed JREs → Add → Standard VM**, chọn thư mục JDK 21. Trong **Execution Environments**, gán JDK đó cho **JavaSE-21** rồi chọn **Project → Clean**.

## 2. Kết nối SQL Server

Ứng dụng dùng SQL Server 2019 trở lên và đăng nhập SQL Server bằng tên người dùng, mật khẩu.

- **Đang dùng database có quét mã và đổi trả.** Mở `database/06_RangBuoc_GreenHome.sql` trong SSMS, chọn đúng instance của project và nhấn F5 để áp dụng ràng buộc cho `QuanLyBanHang`. Thành công khi Messages hiện “Đã đồng bộ ràng buộc GreenHome.” Nếu dữ liệu cũ vi phạm, SQL Server báo tên bảng và tên ràng buộc, đồng thời hoàn tác lần nâng cấp.
- **Máy mới.** Mở `database/01_QuanLyBanHang.sql` và nhấn F5 để tạo cấu trúc và dữ liệu mẫu trong một lần. Đợi Messages hiện “Đã hoàn tất cài đặt QuanLyBanHang.” Results hiển thị 4 sản phẩm và mã hóa đơn mẫu. Ảnh tem và bản in A4 nằm trong `database/Ma_vach/`.
- **Database GreenHome đời cũ chưa nâng cấp quét mã.** Dùng `database/05_DoiTra_QuetMa.sql` để bổ sung bảng, cột và bộ ràng buộc mới. 
- Trong Eclipse, mở `config/db.properties`. Điền `user` và `password` của tài khoản **SQL Server** có quyền đọc, ghi trên database. Sửa máy chủ và cổng trong `url` nếu khác `localhost:1433`, rồi lưu tệp. Với SQL Server Express, kiểm tra TCP/IP đã bật và dùng đúng cổng TCP của instance. Tài khoản SQL cần dùng được chế độ **SQL Server Authentication**.
- Để kiểm tra riêng kết nối, nhấp phải `src/tools/KiemTraKetNoi.java` → **Run As → Java Application**. Xem kết quả kiểm tra bảng và cột ở **Console**.

## 3. Chạy ứng dụng

Trong **Package Explorer**, nhấp phải `src/ui/LoginFrame.java` → **Run As → Java Application**. Project cũng có cấu hình **GreenHome** trong **Run → Run Configurations → Java Application**.

Với database tạo mới bằng 01_QuanLyBanHang.sql, dùng **banhang / BanHang@2026** cho nhân viên hoặc **admin / QuanLy@2026** cho quản lý ở cửa sổ Green Home. Nếu nâng cấp database đang dùng, đăng nhập bằng thông tin hiện tại. Thông tin này chỉ dùng ở cửa sổ ứng dụng. Hai dòng `user` và `password` trong `db.properties` dùng thông tin đăng nhập của SQL Server trên máy bạn.

Bạn có thể mở cửa sổ đăng nhập sau khi import project. Để vào màn hình bán hàng, hãy hoàn thành bước kết nối SQL Server.

## 4. Bán hàng tại quầy

- **Tạo khách khi đang bán**. Bấm **+ Khách mới** để tới trang **Khách hàng**. Nếu đã gõ tên hoặc số điện thoại ở quầy, form nhận lại giá trị đó. Lưu để quay lại giỏ với khách vừa tạo. Hủy để trở lại đơn đang bán.
- **Tra cứu và in**. Mở **Hóa đơn** ở menu trái. Nút **Lịch sử bán hàng**, liên kết hóa đơn trong hồ sơ khách hàng và nút tra cứu trên trang Tổng quan đều dẫn về màn hình này.

1. Kết nối điện thoại và máy tính vào cùng một mạng. Máy tính có thể cắm dây LAN vào cùng bộ phát Wi-Fi. Trong GreenHome, chọn **Bán hàng → Quét mã bằng điện thoại**.
2. Trên máy tính, chọn card mạng Wi-Fi hoặc Ethernet đang dùng. Dùng camera Samsung quét QR trên cửa sổ GreenHome và mở liên kết trên **điện thoại**, rồi bấm **Kết nối quầy**. Có thể gõ địa chỉ bên dưới QR vào trình duyệt điện thoại. Mỗi phiên ghép với một điện thoại và có địa chỉ riêng.
3. Trên điện thoại chọn **Chụp mã vạch**, chụp trọn một tem và xác nhận ảnh nếu máy hỏi. Đặt tem mẫu `database/Ma_vach/SP9801.png` trên màn hình khác hoặc in bản PDF A4. Mỗi ảnh đọc thành công thêm một sản phẩm. Nếu đã cài [Binary Eye cho Android](https://play.google.com/store/apps/details?id=de.markusfisch.android.binaryeye), chọn **Quét bằng Binary Eye** để camera tự nhận tem rồi trở về trang quầy. Bấm lại để quét món tiếp theo.
4. Tên hàng và số lượng hiện trên cả điện thoại và máy tính. Các mã Code 128, Code 39, EAN-13 và EAN-8 có thể đọc bằng chế độ chụp. Với tem chưa đăng ký, chọn đúng sản phẩm trên điện thoại và bấm **Gắn mã và thêm 1**. Ảnh chụp được giải mã ngay trên điện thoại. Nếu mất phản hồi, bấm **Gửi lại lượt vừa quét** để đối chiếu cùng lượt, tránh cộng trùng.
5. Bấm **Kết thúc phiên quét** trên điện thoại hoặc **Kết thúc quét và trở về giỏ** trên máy tính, rồi thanh toán như bình thường. Nếu điện thoại không mở được liên kết, kiểm tra đúng card mạng, tránh Wi-Fi khách có cách ly thiết bị và cho phép Java/OpenJDK trên mạng riêng khi Windows hỏi. Chỉ chia sẻ QR với người đang quét tại quầy và sử dụng mạng nội bộ tin cậy.

## 5. Đổi hoặc trả hàng

- **Nhân viên bán hàng** vào **Đổi / trả → Tiếp nhận đổi / trả**, tìm hóa đơn bằng mã, tên hoặc số điện thoại. Chọn hàng, số lượng, hướng xử lý, tình trạng, phụ kiện, lý do và liên hệ. Hạn tiếp nhận kéo dài đến hết ngày thứ 7 sau ngày mua. Phiếu cũ sửa sau hạn chỉ được giữ hoặc giảm phạm vi số lượng đã tiếp nhận.
- **Quản lý** mở chi tiết phiếu **Chờ duyệt**, chọn **Phê duyệt** hoặc **Từ chối**. Nhân viên lập phiếu có thể sửa và gửi lại phiếu bị từ chối. Với bản cài mới, dùng tài khoản quản lý để tạo nhân viên bán hàng trong chức năng Nhân viên trước khi thử hai vai trò.
- **Chính nhân viên lập phiếu** mở lại phiếu **Đã duyệt**. Chọn **Thực hiện hoàn tiền** để kiểm tra số dự kiến, nhập số thực hoàn và phương thức. Số thực hoàn được nhập từ 0 đến số dự kiến, tối đa hai chữ số thập phân.
- Với **Thực hiện đổi sản phẩm**, chọn hàng thay thế cho từng dòng với cùng số lượng. Giá hàng cũ lấy theo số thực trả sau giảm giá. Hàng thay thế dùng giá niêm yết hiện tại. Màn hình hiển thị số cần thu thêm, số hoàn lại hoặc đổi ngang giá. Với phiếu cũ có cả đổi lẫn trả, hộp xác nhận hiển thị số tiền ròng.
- Sau khi bàn giao hàng và thu hoặc chi tiền tại quầy, nhấn **Xác nhận hoàn tất**. Ứng dụng ghi nhận giao dịch tiền mặt hoặc chuyển khoản do nhân viên xác nhận. Việc gửi lệnh chuyển tiền qua ngân hàng nằm ngoài ứng dụng.
- Phiếu chuyển sang **Hoàn tất**. Lịch sử trong chi tiết hiển thị người và thời gian từng bước, số tiền thực hoàn, chênh lệch và phương thức. Với phiếu cũ chỉ biết người duyệt, lịch sử ghi rõ thiếu thời gian duyệt. Serial/IMEI lấy nguyên từ dòng hóa đơn nếu có. Hàng trả về không tự cộng vào tồn có thể bán. Hàng thay thế được trừ tồn khi hoàn tất.
- Số dư điểm được giữ nguyên. GreenHome có quy tắc bán hàng 1 điểm cho mỗi 100.000 đồng thực trả và 1 điểm dùng tương đương 1.000 đồng. Hóa đơn cũ chỉ lưu tổng giảm do khuyến mãi và do điểm, chưa tách điểm đã dùng ở từng dòng. Dự án cũng chưa có quy định thu hồi điểm đã tiêu khi trả hàng. Giá trị hàng cũ dùng số tiền khách thực trả để tránh hoàn cả phần giảm.
- Bảo hành của dữ liệu cũ vẫn đọc được. Các dòng bảo hành không được quyết toán như một phiếu đổi hoặc trả tiền.

## 6. Tệp cần thay khi ghép vào project đang có

Đường dẫn bên dưới tính từ thư mục `GreenHome`. Import toàn bộ ZIP sẽ lấy đủ các tệp.

| Vị trí | Nội dung |
|---|---|
| `src/ui/BanHangPanel.java` | Giao diện quầy, ghép điện thoại, chọn tay, cập nhật giỏ |
| `src/camera/` | Máy chủ ghép nối trong phiên bán hàng, QR, giao diện điện thoại và bộ đọc mã. Giữ cả thư mục nguồn để Eclipse chép HTML và JavaScript sang bin. |
| `src/bus/BanHangBUS.java`, `src/dao/BanHangDAO.java` | Tra cứu và lưu liên kết giữa tem và sản phẩm |
| `src/ui/DoiTraPanel.java` | Tiếp nhận, duyệt, quyết toán, chi tiết từng dòng và lịch sử |
| `src/bus/DoiTraBUS.java`, `src/dao/DoiTraDAO.java`, `src/dao/GiaoDichDoiTraDAO.java` | Kiểm tra, phân bổ giá trị thực trả, giao dịch SQL, hàng thay thế |
| `src/entity/PhieuDoiTra.java`, `src/entity/ChiTietPhieuDoiTra.java`, `src/entity/TrangThaiDuyet.java` | Hạn theo ngày, tiền thập phân, trạng thái hoàn tất |
| `database/05_DoiTra_QuetMa.sql`, `database/SQLQuery27.sql` | Nâng cấp database đang dùng hoặc cài mới |
| `src/tools/KiemThuDoiTra.java` | Kịch bản kiểm thử trên database riêng |

Script nâng cấp mở rộng ràng buộc trạng thái, thêm bảng lịch sử và bảng liên kết mã quét. Trên chi tiết phiếu, các cột mới lưu giá trị hàng thực trả của cả dòng (kể cả phần lẻ), mã thay thế và giá lúc đổi. Bản nâng cấp giữ các bảng, bản ghi và khóa ngoại nghiệp vụ cũ. Khi số lượng hoặc giá thay đổi giữa lúc chọn và xác nhận, giao dịch cập nhật trạng thái, tồn và lịch sử sẽ được hủy cùng nhau.

## 7. Kiểm thử

Có thể kiểm thử tự động phần đổi trả trên **database thử mới**. Tạo một bản sao của script cài mới, thay toàn bộ `QuanLyBanHang` bằng `GreenHome_QA`, rồi chạy bản sao trong SSMS ở SQLCMD Mode. Tạo bản sao `config/db.properties` tên `config/qa.properties`, đặt databaseName=GreenHome_QA và thông tin kết nối phù hợp. Trong Eclipse, tạo cấu hình Java Application cho `tools.KiemThuDoiTra`, đặt VM arguments là `-Dgreenhome.config=config/qa.properties`. Kịch bản tạo dữ liệu thử và để lại phiếu để kiểm tra trong SQL. Mỗi lần chạy cần một database QA mới.

Kịch bản bao phủ quyền duyệt, từ chối và gửi lại, số tiền lẻ, serial, hoàn tiền, đổi hàng đắt hơn/rẻ hơn/ngang giá, giá hoặc tồn thay đổi, chặn hoàn tất hai lần và chặn trả quá số đã mua. Để thử camera trên máy thật, quét một tem có mã mới, gắn mã, rồi thực hiện một lượt quét mới với cùng tem. Kết quả mong đợi là cùng một dòng giỏ hàng với số lượng 2.

Khi đóng gói, mã Java được biên dịch bằng JDK 21. Kịch bản nghiệp vụ đã chạy qua lớp JDBC mô phỏng SQL Server với dữ liệu SQLite. Bộ đọc ảnh đã được thử bằng mã vạch dựng độc lập và chiều đọc đảo ngược, đồng thời kiểm tra việc gửi trùng yêu cầu quét. Webcam vật lý, Eclipse có giao diện và SQL Server thật cần được kiểm tra trong môi trường cài đặt.
